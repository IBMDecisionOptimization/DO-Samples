from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys



# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


from pandas.api.types import is_string_dtype


def helper_check_data_type(df, column, df_label, check_type):
    if not column in df.columns:
        print('Column "%s" does not exist in table "%s"' % (column, df_label))
        return False
    non_nan_values = df[column][~df[column].isnull()]
    if check_type == 'INTEGER':
        k = non_nan_values.dtype.kind
        if k != 'i':
            if k == 'f':
                non_integer_values = non_nan_values.values[np.where([not x.is_integer() for x in non_nan_values])]
                if len(non_integer_values) > 0:
                    print('Column "%s" of table "%s" contains non-integer value(s) which violates expected type: %s' % (column, df_label, non_integer_values))
                    return False
            else:
                print('Column "%s" of table "%s" is non-numeric which violates expected type: %s' % (column, df_label, non_nan_values.values))
                return False
    elif check_type == 'FLOAT' or check_type == 'NUMBER':
        non_float_values = non_nan_values.values[np.where([not isinstance(x, (int, float)) for x in non_nan_values])]
        k = non_nan_values.dtype.kind
        if not k in ['i', 'f']:
            print('Column "%s" of table "%s" contains non-float value(s) which violates expected type: %s' % (column, df_label, non_float_values))
            return False
    elif check_type == 'BOOLEAN':
        non_bool_values = non_nan_values.values[np.where([not isinstance(x, bool) and not x in [0, 1] for x in non_nan_values])]
        if len(non_bool_values) > 0:
            print('Column "%s" of table "%s" contains non-boolean value(s) which violates expected type: %s' % (column, df_label, non_bool_values))
            return False
    elif check_type == 'Date' or check_type == 'DateTime':
        try:
            pd.to_datetime(non_nan_values)
        except ValueError as e:
            print('Column "%s" of table "%s" cannot be converted to a DateTime : %s' % (column, df_label, str(e)))
            return False
    elif check_type == 'Time':
        try:
            pd.to_timedelta(non_nan_values)
        except ValueError as e:
            try:
                # Try appending ':00' in case seconds are not represented in time
                pd.to_timedelta(non_nan_values + ':00')
            except ValueError as e:
                print('Column "%s" of table "%s" cannot be converted to a Time : %s' % (column, df_label, str(e)))
                return False
    elif check_type == 'STRING':
        if not is_string_dtype(non_nan_values):
            print('Column "%s" of table "%s" is not of type "String"' % (column, df_label))
            return False
    else:
        raise Exception('Invalid check_type: %s' % check_type)
    return True


def helper_check_foreignKey_values(source_df, source_column, source_df_label, target_df, target_column, target_df_label):
    non_nan_values = source_df[source_column][~source_df[source_column].isnull()]
    invalid_FK_values = non_nan_values[~non_nan_values.isin(target_df[target_column])].values
    if len(invalid_FK_values) > 0:
        print('FK Column "%s" of table "%s" contains values that do not exist in PK column "%s" of target table "%s": %s' % (source_column, source_df_label, target_column, target_df_label, invalid_FK_values))
        return False
    return True


def helper_check_unique_primaryKey_values(df, key_cols, df_label):
    df_grp = df.groupby(key_cols).size()
    invalid_pk_values = df_grp[df_grp > 1].reset_index()[key_cols].values
    if len(invalid_pk_values) > 0:
        print('Non-unique values for PK of table "%s": %s' % (df_label, invalid_pk_values))
        return False
    return True


# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'Campaign': ['id_of_Campaign'],
    'Candidates': ['id_of_Candidates'],
    'Customer': ['id_of_Customer'],
    'cActivity': ['id_of_Campaign'],
    'cAssignmentValueConcept': ['id_of_Candidates'],
    'cResource': ['id_of_Customer'],
    'cResourceAssignment': ['id_of_Campaign', 'id_of_Customer'],
    'cResourceAssignment__Customer__Campaign__': ['id_of_Campaign', 'id_of_Customer']}
helper_property_id_to_column_names_map = {
    'Candidates.Campaign': 'Campaign',
    'Candidates.Customer': 'Customer',
    'Candidates.expected value': 'expected_value',
    'cAssignmentValueConcept.activity': 'Campaign',
    'cAssignmentValueConcept.resource': 'Customer',
    'cAssignmentValueConcept.value': 'expected_value'}


# Data model definition for each table
# Data collection: list_of_Campaign ['id']
# Data collection: list_of_Candidates ['Campaign', 'Customer', 'expected_value', '__line']
# Data collection: list_of_Customer ['id']

# Create a pandas Dataframe for each data table
list_of_Candidates = inputs[u'Candidates']
list_of_Candidates = list_of_Candidates[[u'Campaign', u'Customer', u'expected value']].copy()
list_of_Candidates.rename(columns={u'Campaign': 'Campaign', u'Customer': 'Customer', u'expected value': 'expected_value'}, inplace=True)
# --- Handling table for implicit concept
list_of_Campaign = pd.DataFrame(inputs[u'Candidates']['Campaign'].unique(), columns=['id']).dropna()
# --- Handling table for implicit concept
list_of_Customer = pd.DataFrame(inputs[u'Candidates']['Customer'].unique(), columns=['id']).dropna()

# Perform input data checking against schema configured in Modelling Assistant along with unicity of PK values
data_check_result = True
# --- Handling data checking for implicit concept: Campaign
# --- Handling data checking for table: Candidates
data_check_result &= helper_check_foreignKey_values(list_of_Candidates, 'Campaign', 'Candidates', list_of_Campaign, 'id', 'Campaign')
data_check_result &= helper_check_foreignKey_values(list_of_Candidates, 'Customer', 'Candidates', list_of_Customer, 'id', 'Customer')
data_check_result &= helper_check_data_type(list_of_Candidates, 'expected_value', 'Candidates', 'NUMBER')
# --- Handling data checking for implicit concept: Customer
if not data_check_result:
    # Stop execution here
    raise Exception('Data checking detected errors')

# Force column type for non-numeric columns
list_of_Campaign = list_of_Campaign.astype({'id': object})
list_of_Candidates = list_of_Candidates.astype({'Campaign': object, 'Customer': object})
list_of_Customer = list_of_Customer.astype({'id': object})

# Set index when a primary key is defined
list_of_Campaign.set_index('id', inplace=True)
list_of_Campaign.sort_index(inplace=True)
list_of_Campaign.index.name = 'id_of_Campaign'
list_of_Candidates.index.name = 'id_of_Candidates'
list_of_Customer.set_index('id', inplace=True)
list_of_Customer.sort_index(inplace=True)
list_of_Customer.index.name = 'id_of_Customer'


# Create data frame as cartesian product of: Customer x Campaign
list_of_ResourceAssignment = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Customer.index, list_of_Campaign.index), names=['id_of_Customer', 'id_of_Campaign']))





def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_ResourceAssignment['resourceAssignmentVar'] = mdl.binary_var_list(len(list_of_ResourceAssignment))



    # Definition of model
    # Objective cMaximizeAssignmentsAutoSelected-
    # Combine weighted criteria: 
    # 	cMaximizeAssignmentsAutoSelected cMaximizeAssignmentsAutoSelected 1.2{
    # 	assignment = cResourceAssignment__Customer__Campaign__,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = decisionPath(cResourceAssignment__Customer__Campaign__)} with weight 5.0
    # 	cMaximizeAssignmentValue cMaximizeAssignmentValue 1.2{
    # 	assignment = cResourceAssignment__Customer__Campaign__,
    # 	assignmentValue = Candidates,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = total Candidates [cResourceAssignment__Customer__Campaign__ / Customer==Candidates / Customer, cResourceAssignment__Customer__Campaign__ / Campaign==Candidates / Campaign] / expected value over cResourceAssignment} with weight 5.0
    agg_ResourceAssignment_resourceAssignmentVar_SG1 = mdl.sum(list_of_ResourceAssignment.resourceAssignmentVar)
    join_ResourceAssignment_SG2 = list_of_ResourceAssignment.reset_index().merge(list_of_Candidates.reset_index(), left_on=['id_of_Customer', 'id_of_Campaign'], right_on=['Customer', 'Campaign']).set_index(['id_of_Customer', 'id_of_Campaign', 'id_of_Candidates'])
    join_Candidates_SG2 = list_of_Candidates.join(join_ResourceAssignment_SG2, rsuffix='_right', how='inner')
    groupby_Candidates_SG2 = join_Candidates_SG2.expected_value.groupby(level=['id_of_Customer', 'id_of_Campaign']).sum().to_frame()
    join_ResourceAssignment_SG2_2 = list_of_ResourceAssignment.reset_index().merge(groupby_Candidates_SG2.reset_index(), left_on=['id_of_Customer', 'id_of_Campaign'], right_on=['id_of_Customer', 'id_of_Campaign']).set_index(['id_of_Customer', 'id_of_Campaign'])
    join_ResourceAssignment_SG2_2['conditioned_expected_value'] = join_ResourceAssignment_SG2_2.resourceAssignmentVar * join_ResourceAssignment_SG2_2.expected_value
    agg_ResourceAssignment_conditioned_expected_value_SG2 = mdl.sum(join_ResourceAssignment_SG2_2.conditioned_expected_value)
    
    kpis_expression_list = [
        (1, 16.0, agg_ResourceAssignment_resourceAssignmentVar_SG1, 1, 0, u'the number of Customer-Campaign assignments'),
        (1, 16.0, agg_ResourceAssignment_conditioned_expected_value_SG2, 1, 0, u'overall quality or value of Customer-Campaign assignments according to Candidates')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_expr, publish_name=kpi_name)
    
    mdl.maximize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cLimitNumberOfResourcesAssignedToEachActivity#1_cIterativeRelationalConstraint
    # The number of Customers assigned to each Campaign is less than or equal to 3
    # Label: CT_1_The_number_of_Customers_assigned_to_each_Campaign_is_less_than_or_equal_to_3
    groupbyLevels = ['id_of_Campaign']
    groupby_ResourceAssignment = list_of_ResourceAssignment.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_ResourceAssignment.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAssignmentVar <= 3, u'The number of Customers assigned to each Campaign is less than or equal to 3', row)
    
    # [ST_2] Constraint : cBasicLimitNumberOfActivitiesAssignedToEachResource#1_cIterativeRelationalConstraint
    # The number of Campaigns assigned to each Customer is less than or equal to 1
    # Label: CT_2_The_number_of_Campaigns_assigned_to_each_Customer_is_less_than_or_equal_to_1
    groupbyLevels = ['id_of_Customer']
    groupby_ResourceAssignment = list_of_ResourceAssignment.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_ResourceAssignment.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAssignmentVar <= 1, u'The number of Campaigns assigned to each Customer is less than or equal to 1', row)


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    if mdl.get_solve_status() == JobSolveStatus.UNKNOWN:
        print('UNKNOWN cause: %s' % mdl.get_solve_details().status)
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('Internal constraint', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = pd.concat([list_of_conflicts, pd.DataFrame({'constraint': [label], 'context': [str(context)], 'detail': [ct]})],
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_ResourceAssignment_solution = pd.DataFrame(index=list_of_ResourceAssignment.index)
    list_of_ResourceAssignment_solution['resourceAssignmentVar'] = msol.get_values(list_of_ResourceAssignment.resourceAssignmentVar.values)
    AssignedCampaigns = pd.DataFrame(index=list_of_ResourceAssignment.index)
    
    # Adding extra columns based on Solution Schema
    groupbyLevels = ['id_of_Customer', 'id_of_Campaign']
    groupby_ResourceAssignment = list_of_ResourceAssignment_solution.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    AssignedCampaigns['Campaign assignments'] = groupby_ResourceAssignment['resourceAssignmentVar']
    groupbyLevels = ['id_of_Customer', 'id_of_Campaign']
    groupby_ResourceAssignment = list_of_ResourceAssignment_solution.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    AssignedCampaigns['Customer assignments'] = groupby_ResourceAssignment['resourceAssignmentVar']
    AssignedCampaigns = AssignedCampaigns.round({'Campaign assignments': 2, 'Customer assignments': 2})
    
    AssignedCampaigns['_INTERNAL_resourceAssignmentVar'] = list_of_ResourceAssignment_solution.resourceAssignmentVar
    AssignedCampaigns = AssignedCampaigns[AssignedCampaigns._INTERNAL_resourceAssignmentVar > 0.5]
    AssignedCampaigns = AssignedCampaigns.drop('_INTERNAL_resourceAssignmentVar', axis='columns')


    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['AssignedCampaigns'] = AssignedCampaigns[['Campaign assignments', 'Customer assignments']].reset_index().rename(columns= {'id_of_Campaign': 'Campaign', 'id_of_Customer': 'Customer'})
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Instantiate CustomCode class if definition exists
try:
    custom_code = CustomCode(globals())
except NameError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()


from docplex.mp.progress import ProgressListener
from docplex.util.environment import add_abort_callback, remove_abort_callback
from functools import partial


class SolutionListener(ProgressListener):
    def __init__(self):
        super(SolutionListener, self).__init__()
        self._cpx_incumbent_sol = None

    def requires_solution(self):
        return True

    def notify_solution(self, cpx_incumbent_sol):
        self._cpx_incumbent_sol = cpx_incumbent_sol
        # print("Solution found. Objective={}".format(cpx_incumbent_sol.get_objective_value()))
        export_solution(cpx_incumbent_sol)
        try:
            global settings_publish_intermediate_solution
            if (settings_publish_intermediate_solution):
                write_all_outputs(outputs)  
        except:
            pass

def save_and_write_last_solution_callback(sol_listener, outputs):
    if sol_listener._cpx_incumbent_sol:
        export_solution(sol_listener._cpx_incumbent_sol)
    write_all_outputs(outputs)


solution_listener = SolutionListener()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

#
model.add_progress_listener(solution_listener)
env = get_environment()
# Remove default abort callbacks
for cb in env.abort_callbacks:
    remove_abort_callback(cb)
# Add new abort callback to store latest found solution, if any
add_abort_callback(partial(save_and_write_last_solution_callback, solution_listener, outputs))

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
