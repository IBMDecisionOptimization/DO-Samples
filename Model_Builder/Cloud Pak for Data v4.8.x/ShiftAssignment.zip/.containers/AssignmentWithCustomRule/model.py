from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys

#dd-markdown <h1>BEGIN Python Custom Code section custom_code.py</h1>
#dd-cell
##--- Begin custom rule class CustomCode

class CustomCode:
    def __init__(self, ctxt):
        self.ctxt = ctxt
        self.update_globals(ctxt)

    def update_globals(self, ctxt):
        # Add all global variables from calling environment to current name space for easy access
        globals().update(ctxt)
        
    ##--- Functions implementing custom rules
    
    ##--- Custom rule function limitConsecutiveAssignments (id: 95b690d8-e5a8-4218-93b4-f0218a1687cd)

    # -- # Data Structure for parameter: employees   --------------------
    # -- # DataFrame: Employee
    # -- # PrimaryKey  : id_of_Employee
    # -- #             : pay rate
    # -- #             : qualification
    # -- #             : seniority
    # -- #
    # -- # Data Structure for parameter: on_call_duties   --------------------
    # -- # DataFrame: OnCallDuty
    # -- # PrimaryKey  : id_of_Day
    # -- # PrimaryKey  : id_of_Employee
    # -- # DecisionVar : onCallDutyVar
    # -- #
    def limitConsecutiveAssignments(self, mdl, employees, on_call_duties, limit):
        global helper_add_labeled_cplex_constraint, helper_get_index_names_for_type, helper_get_column_name_for_property
        print('Adding constraints for the custom rule')
        for employee, duties in employees.associated(on_call_duties):
            duties_day_idx = duties.join(Day)  # Retrieve Day index from Day label
            for d in Day['index']:
                end = d + limit + 1  # One must enforce that there are no occurence of (limit + 1) working consecutive days
                duties_in_win = duties_day_idx[((duties_day_idx['index'] >= d) & (duties_day_idx['index'] <= end)) | (duties_day_idx['index'] <= end - 7)]
                mdl.add_constraint(mdl.sum(duties_in_win.onCallDutyVar) <= limit)
 
    ##--- Other customization functions (can be optionally refined)

    def preprocess(self):
        """
        Code to pre-process input data or importing more input data
        """
        print('CUSTOM RULES preprocess %%')
        pass

    def update_goals_list(self, kpis_expression_list):
        """
        'kpis_expression_list' is a list of tuples (kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name)
        defining the objective. The objective is computed according to the following expression:
        sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list])
        This list may be updated in this method in order to customize the definition of the objective.
        """
        pass

    def update_model(self, mdl):
        """
        Code to add new decision variables and/or more constraints
        """
        print('CUSTOM RULES update model')
        pass

    def update_solver_params(self, params):
        """
        Code to configure solver parameters
        """
        # Example: Update default value for solver time limit to 10 seconds
        # params.timelimit = 10

    def post_process_solution(self, msol, outputs):
        """
        Code to:
           - post-process intermediate solution: add calculated columns to solution dataframes,...
           - add custom columns to existing exported dataframes
        """
        print('CUSTOM RULES postprocess')
        pass

##--- End custom rule class CustomCode



#dd-markdown <h1> END Python Custom Code section</h1>


# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


from pandas.api.types import is_string_dtype


def helper_check_data_type(df, column, df_label, check_type):
    if not column in df.columns:
        print('Column "%s" does not exist in table "%s"' % (column, df_label))
        return False
    non_nan_values = df[column][~df[column].isnull()]
    if check_type == 'INTEGER':
        k = non_nan_values.dtype.kind
        if k != 'i':
            if k == 'f':
                non_integer_values = non_nan_values.values[np.where([not x.is_integer() for x in non_nan_values])]
                if len(non_integer_values) > 0:
                    print('Column "%s" of table "%s" contains non-integer value(s) which violates expected type: %s' % (column, df_label, non_integer_values))
                    return False
            else:
                print('Column "%s" of table "%s" is non-numeric which violates expected type: %s' % (column, df_label, non_nan_values.values))
                return False
    elif check_type == 'FLOAT' or check_type == 'NUMBER':
        non_float_values = non_nan_values.values[np.where([not isinstance(x, (int, float)) for x in non_nan_values])]
        k = non_nan_values.dtype.kind
        if not k in ['i', 'f']:
            print('Column "%s" of table "%s" contains non-float value(s) which violates expected type: %s' % (column, df_label, non_float_values))
            return False
    elif check_type == 'BOOLEAN':
        non_bool_values = non_nan_values.values[np.where([not isinstance(x, bool) and not x in [0, 1] for x in non_nan_values])]
        if len(non_bool_values) > 0:
            print('Column "%s" of table "%s" contains non-boolean value(s) which violates expected type: %s' % (column, df_label, non_bool_values))
            return False
    elif check_type == 'Date' or check_type == 'DateTime':
        try:
            pd.to_datetime(non_nan_values)
        except ValueError as e:
            print('Column "%s" of table "%s" cannot be converted to a DateTime : %s' % (column, df_label, str(e)))
            return False
    elif check_type == 'Time':
        try:
            pd.to_timedelta(non_nan_values)
        except ValueError as e:
            try:
                # Try appending ':00' in case seconds are not represented in time
                pd.to_timedelta(non_nan_values + ':00')
            except ValueError as e:
                print('Column "%s" of table "%s" cannot be converted to a Time : %s' % (column, df_label, str(e)))
                return False
    elif check_type == 'STRING':
        if not is_string_dtype(non_nan_values):
            print('Column "%s" of table "%s" is not of type "String"' % (column, df_label))
            return False
    else:
        raise Exception('Invalid check_type: %s' % check_type)
    return True


def helper_check_foreignKey_values(source_df, source_column, source_df_label, target_df, target_column, target_df_label):
    non_nan_values = source_df[source_column][~source_df[source_column].isnull()]
    invalid_FK_values = non_nan_values[~non_nan_values.isin(target_df[target_column])].values
    if len(invalid_FK_values) > 0:
        print('FK Column "%s" of table "%s" contains values that do not exist in PK column "%s" of target table "%s": %s' % (source_column, source_df_label, target_column, target_df_label, invalid_FK_values))
        return False
    return True


def helper_check_unique_primaryKey_values(df, key_cols, df_label):
    df_grp = df.groupby(key_cols).size()
    invalid_pk_values = df_grp[df_grp > 1].reset_index()[key_cols].values
    if len(invalid_pk_values) > 0:
        print('Non-unique values for PK of table "%s": %s' % (df_label, invalid_pk_values))
        return False
    return True


# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'Day': ['id_of_Day'],
    'Employee': ['id_of_Employee'],
    'OnCallDuty': ['id_of_Day', 'id_of_Employee'],
    'Shift': ['id_of_Shift'],
    '__CombinationOf__Employee__Day__': ['id_of_Day', 'id_of_Employee'],
    'cActivity': ['id_of_Shift'],
    'cAssignmentDecision': ['id_of_Day', 'id_of_Employee'],
    'cResource': ['id_of_Employee'],
    'cResourceAssignment': ['id_of_Employee', 'id_of_Shift'],
    'cResourceAssignment__Employee__Shift__': ['id_of_Employee', 'id_of_Shift'],
    'department': ['id_of_Department'],
    'skills': ['id_of_Skills']}
helper_property_id_to_column_names_map = {
    'Day.index': 'index_',
    'Day.on-call requirement': 'oncall_requirement',
    'Employee.pay rate': 'pay_rate',
    'Employee.qualification': 'qualification',
    'Employee.seniority': 'seniority',
    'Shift.End date': 'End_date',
    'Shift.Start date': 'Start_date',
    'Shift.Week start': 'Week_start',
    'Shift.day': 'day',
    'Shift.day index': 'day_index',
    'Shift.department': 'department',
    'Shift.duration': 'duration',
    'Shift.end time': 'end_time',
    'Shift.max req': 'max_req',
    'Shift.min req': 'min_req',
    'Shift.requested skills': 'requested_skills',
    'Shift.start time': 'start_time'}


# Data model definition for each table
# Data collection: list_of_Day ['oncall_requirement', 'name', 'index_']
# Data collection: list_of_Employee ['seniority', 'qualification', 'pay_rate', 'name', 'pay_rate', 'qualification']
# Data collection: list_of_Employee_skills ['Employee', 'skills']
# Data collection: list_of_Employee_days_off ['Employee', 'days_off']
# Data collection: list_of_Shift ['start_time', 'shiftId', 'requested_skills', 'min_req', 'max_req', 'end_time', 'duration', 'department', 'day_index', 'day', 'Week_start', 'Start_date', 'End_date']
# Data collection: list_of_Department ['id']
# Data collection: list_of_Skills ['id']

# Create a pandas Dataframe for each data table
list_of_Day = inputs[u'Day']
list_of_Day = list_of_Day[[u'on-call requirement', u'name', u'index']].copy()
list_of_Day.rename(columns={u'on-call requirement': 'oncall_requirement', u'name': 'name', u'index': 'index_'}, inplace=True)
list_of_Employee = inputs[u'Employee']
list_of_Employee = list_of_Employee[[u'seniority', u'qualification', u'pay rate', u'name']].copy()
list_of_Employee.rename(columns={u'seniority': 'seniority', u'qualification': 'qualification', u'pay rate': 'pay_rate', u'name': 'name'}, inplace=True)
list_of_Shift = inputs[u'Shift']
list_of_Shift = list_of_Shift[[u'start time', u'shiftId', u'requested skills', u'min req', u'max req', u'end time', u'duration', u'department', u'day index', u'day', u'Week start', u'Start date', u'End date']].copy()
list_of_Shift.rename(columns={u'start time': 'start_time', u'shiftId': 'shiftId', u'requested skills': 'requested_skills', u'min req': 'min_req', u'max req': 'max_req', u'end time': 'end_time', u'duration': 'duration', u'department': 'department', u'day index': 'day_index', u'day': 'day', u'Week start': 'Week_start', u'Start date': 'Start_date', u'End date': 'End_date'}, inplace=True)
# --- Handling implicit table for multi-valued property
list_of_Employee_skills = inputs[u'Employee'][[u'name', u'skills']].copy().dropna(how='any')
list_of_Employee_skills.rename(columns={u'name': 'Employee', u'skills': 'skills'}, inplace=True)
if len(list_of_Employee_skills) > 0:
    list_of_Employee_skills.set_index('Employee', inplace=True)
    list_of_Employee_skills_split = list_of_Employee_skills['skills'].str.split(',').apply(pd.Series).stack().str.strip()
    list_of_Employee_skills_split.index = list_of_Employee_skills_split.index.droplevel(-1)
    list_of_Employee_skills = pd.DataFrame(list_of_Employee_skills_split, columns=['skills']).reset_index()
# --- Handling implicit table for multi-valued property
list_of_Employee_days_off = inputs[u'Employee'][[u'name', u'days off']].copy().dropna(how='any')
list_of_Employee_days_off.rename(columns={u'name': 'Employee', u'days off': 'days_off'}, inplace=True)
if len(list_of_Employee_days_off) > 0:
    list_of_Employee_days_off.set_index('Employee', inplace=True)
    list_of_Employee_days_off_split = list_of_Employee_days_off['days_off'].str.split(',').apply(pd.Series).stack().str.strip()
    list_of_Employee_days_off_split.index = list_of_Employee_days_off_split.index.droplevel(-1)
    list_of_Employee_days_off = pd.DataFrame(list_of_Employee_days_off_split, columns=['days_off']).reset_index()
# --- Handling table for implicit concept
list_of_Department = pd.DataFrame(inputs[u'Shift']['department'].unique(), columns=['id']).dropna()
# --- Handling table for implicit concept
list_of_Skills = pd.DataFrame(list_of_Employee_skills['skills'].unique(), columns=['id']).dropna()
list_of_Skills = pd.DataFrame(pd.concat(objs = [list_of_Skills['id'], inputs[u'Shift']['requested skills']]).unique(), columns=['id']).dropna()

# Perform input data checking against schema configured in Modelling Assistant along with unicity of PK values
data_check_result = True
# --- Handling data checking for table: Day
data_check_result &= helper_check_data_type(list_of_Day, 'oncall_requirement', 'Day', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Day, 'index_', 'Day', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Day, ['name'], 'Day')
# --- Handling data checking for table: Employee
data_check_result &= helper_check_data_type(list_of_Employee, 'seniority', 'Employee', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Employee, 'qualification', 'Employee', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Employee, 'pay_rate', 'Employee', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Employee, ['name'], 'Employee')
# --- Handling data checking for implicit table: Employee_skills
data_check_result &= helper_check_foreignKey_values(list_of_Employee_skills, 'Employee', 'Employee_skills', list_of_Employee, 'name', 'Employee')
data_check_result &= helper_check_foreignKey_values(list_of_Employee_skills, 'skills', 'Employee_skills', list_of_Skills, 'id', 'skills')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Employee_skills, ['Employee', 'skills'], 'Employee_skills')
# --- Handling data checking for implicit table: Employee_days off
data_check_result &= helper_check_foreignKey_values(list_of_Employee_days_off, 'Employee', 'Employee_days off', list_of_Employee, 'name', 'Employee')
data_check_result &= helper_check_foreignKey_values(list_of_Employee_days_off, 'days_off', 'Employee_days off', list_of_Day, 'name', 'Day')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Employee_days_off, ['Employee', 'days_off'], 'Employee_days off')
# --- Handling data checking for table: Shift
data_check_result &= helper_check_data_type(list_of_Shift, 'start_time', 'Shift', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Shift, 'shiftId', 'Shift', 'NUMBER')
data_check_result &= helper_check_foreignKey_values(list_of_Shift, 'requested_skills', 'Shift', list_of_Skills, 'id', 'skills')
data_check_result &= helper_check_data_type(list_of_Shift, 'min_req', 'Shift', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Shift, 'max_req', 'Shift', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Shift, 'end_time', 'Shift', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Shift, 'duration', 'Shift', 'NUMBER')
data_check_result &= helper_check_foreignKey_values(list_of_Shift, 'department', 'Shift', list_of_Department, 'id', 'department')
data_check_result &= helper_check_data_type(list_of_Shift, 'day_index', 'Shift', 'NUMBER')
data_check_result &= helper_check_foreignKey_values(list_of_Shift, 'day', 'Shift', list_of_Day, 'name', 'Day')
data_check_result &= helper_check_data_type(list_of_Shift, 'Week_start', 'Shift', 'DateTime')
data_check_result &= helper_check_data_type(list_of_Shift, 'Start_date', 'Shift', 'DateTime')
data_check_result &= helper_check_data_type(list_of_Shift, 'End_date', 'Shift', 'DateTime')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Shift, ['shiftId'], 'Shift')
# --- Handling data checking for implicit concept: department
# --- Handling data checking for implicit concept: skills
if not data_check_result:
    # Stop execution here
    raise Exception('Data checking detected errors')

# Force column type for non-numeric columns
list_of_Day = list_of_Day.astype({'name': object})
list_of_Employee = list_of_Employee.astype({'name': object})
list_of_Employee_skills = list_of_Employee_skills.astype({'Employee': object, 'skills': object})
list_of_Employee_days_off = list_of_Employee_days_off.astype({'Employee': object, 'days_off': object})
list_of_Shift = list_of_Shift.astype({'requested_skills': object, 'department': object, 'day': object})
list_of_Department = list_of_Department.astype({'id': object})
list_of_Skills = list_of_Skills.astype({'id': object})

# Set index when a primary key is defined
list_of_Day.set_index('name', inplace=True)
list_of_Day.sort_index(inplace=True)
list_of_Day.index.name = 'id_of_Day'
list_of_Employee.set_index('name', inplace=True)
list_of_Employee.sort_index(inplace=True)
list_of_Employee.index.name = 'id_of_Employee'
list_of_Employee_skills.set_index('Employee', inplace=True)
list_of_Employee_skills.sort_index(inplace=True)
list_of_Employee_skills.index.name = 'id_of_Employee'
list_of_Employee_days_off.set_index('Employee', inplace=True)
list_of_Employee_days_off.sort_index(inplace=True)
list_of_Employee_days_off.index.name = 'id_of_Employee'
list_of_Shift.set_index('shiftId', inplace=True)
list_of_Shift.sort_index(inplace=True)
list_of_Shift.index.name = 'id_of_Shift'
list_of_Department.set_index('id', inplace=True)
list_of_Department.sort_index(inplace=True)
list_of_Department.index.name = 'id_of_Department'
list_of_Skills.set_index('id', inplace=True)
list_of_Skills.sort_index(inplace=True)
list_of_Skills.index.name = 'id_of_Skills'
# Parse Date and Time input columns
list_of_Shift['Week_start'] = pd.to_datetime(list_of_Shift['Week_start'])
list_of_Shift['Start_date'] = pd.to_datetime(list_of_Shift['Start_date'])
list_of_Shift['End_date'] = pd.to_datetime(list_of_Shift['End_date'])


# Create data frame as cartesian product of: Employee x Day
list_of___CombinationOf__Employee__Day_ = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Employee.index, list_of_Day.index), names=['id_of_Employee', 'id_of_Day']))
# Create data frame as cartesian product of: Day x Employee
list_of_OnCallDuty = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Day.index, list_of_Employee.index), names=['id_of_Day', 'id_of_Employee']))
# Create data frame as cartesian product of: Employee x Shift
list_of_ResourceAssignment = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Employee.index, list_of_Shift.index), names=['id_of_Employee', 'id_of_Shift']))



class CognitiveSeries(pd.Series):
    @property
    def _constructor(self):
        return CognitiveSeries

    @property
    def _constructor_expanddim(self):
        return CognitiveDataFrame


class CognitiveDataFrame(pd.DataFrame):
    def __init__(self, *args, concept_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.concept_id = concept_id

    @property
    def _constructor(self):
        return CognitiveDataFrame

    @property
    def _constructor_sliced(self):
        return CognitiveSeries

    def associated(self, target):
        return self.join(target).groupby(self.index.name)

def init_cognitive_data_model():
    global Day
    global Employee
    global OnCallDuty
    global Shift
    global __CombinationOf__Employee__Day__
    global cResourceAssignment__Employee__Shift__
    global department
    global skills

    # DataFrame: Day
    # PrimaryKey  : id_of_Day
    #             : index
    #             : on-call requirement
    Day = CognitiveDataFrame(list_of_Day.copy(deep=False))
    Day.rename(columns={'index_': 'index', 'oncall_requirement': 'on-call requirement'}, inplace=True)

    # DataFrame: Employee
    # PrimaryKey  : id_of_Employee
    #             : pay rate
    #             : qualification
    #             : seniority
    Employee = CognitiveDataFrame(list_of_Employee.copy(deep=False))
    Employee.rename(columns={'pay_rate': 'pay rate'}, inplace=True)

    # DataFrame: OnCallDuty
    # PrimaryKey  : id_of_Day
    # PrimaryKey  : id_of_Employee
    # DecisionVar : onCallDutyVar
    OnCallDuty = CognitiveDataFrame(list_of_OnCallDuty.copy(deep=False))

    # DataFrame: Shift
    # PrimaryKey  : id_of_Shift
    #             : End date
    #             : Start date
    #             : Week start
    #             : day
    #             : day index
    #             : department
    #             : duration
    #             : end time
    #             : max req
    #             : min req
    #             : requested skills
    #             : start time
    Shift = CognitiveDataFrame(list_of_Shift.copy(deep=False))
    Shift.rename(columns={'End_date': 'End date', 'Start_date': 'Start date', 'Week_start': 'Week start', 'day_index': 'day index', 'end_time': 'end time', 'max_req': 'max req', 'min_req': 'min req', 'requested_skills': 'requested skills', 'start_time': 'start time'}, inplace=True)

    # DataFrame: __CombinationOf__Employee__Day__
    # PrimaryKey  : id_of_Day
    # PrimaryKey  : id_of_Employee
    __CombinationOf__Employee__Day__ = CognitiveDataFrame(list_of___CombinationOf__Employee__Day_.copy(deep=False))

    # DataFrame: cResourceAssignment__Employee__Shift__
    # PrimaryKey  : id_of_Employee
    # PrimaryKey  : id_of_Shift
    # DecisionVar : resourceAssignmentVar
    cResourceAssignment__Employee__Shift__ = CognitiveDataFrame(list_of_ResourceAssignment.copy(deep=False))

    # DataFrame: department
    # PrimaryKey  : id_of_Department
    department = CognitiveDataFrame(list_of_Department.copy(deep=False))

    # DataFrame: skills
    # PrimaryKey  : id_of_Skills
    skills = CognitiveDataFrame(list_of_Skills.copy(deep=False))

    # Update variables in global scope of custom_code instance
    custom_code.update_globals(globals())


def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_OnCallDuty['onCallDutyVar'] = mdl.binary_var_list(len(list_of_OnCallDuty))
    list_of_ResourceAssignment['resourceAssignmentVar'] = mdl.binary_var_list(len(list_of_ResourceAssignment))

    init_cognitive_data_model()

    # Definition of model
    # Objective cMaximizeAssignmentsAutoSelected#1-
    # Combine weighted criteria: 
    # 	cMaximizeAssignmentsAutoSelected cMaximizeAssignmentsAutoSelected 1.2{
    # 	assignment = cResourceAssignment__Employee__Shift__,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = decisionPath(cResourceAssignment__Employee__Shift__)} with weight 5.0
    # 	cEqualizeGoal cEqualizeGoal 1.2{
    # 	origin = Employee,
    # 	numericExpr = decisionPath(Employee / inverse(OnCallDuty.Employee)),
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null} with weight 5.0
    agg_ResourceAssignment_resourceAssignmentVar_SG1 = mdl.sum(list_of_ResourceAssignment.resourceAssignmentVar)
    groupbyLevels_SG2 = ['id_of_Employee']
    groupby_OnCallDuty_SG2 = list_of_OnCallDuty.onCallDutyVar.groupby(level=groupbyLevels_SG2).sum().to_frame()
    join_Employee_SG2 = list_of_Employee.join(groupby_OnCallDuty_SG2.onCallDutyVar, how='inner')
    agg_Employee_SG2_data = mdl.sumsq(join_Employee_SG2.onCallDutyVar)
    
    kpis_expression_list = [
        (-1, 16.0, agg_ResourceAssignment_resourceAssignmentVar_SG1, 1, 0, u'the number of Employee-Shift assignments'),
        (1, 16.0, agg_Employee_SG2_data, 1, 0, u'number of OnCallDuties over Employees')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_expr, publish_name=kpi_name)
    
    mdl.minimize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cLimitNumberOfResourcesAssignedToEachActivity#1_cIterativeRelationalConstraint
    # The number of Employees assigned to each Shift is less than or equal to max req
    # Label: CT_1_The_number_of_Employees_assigned_to_each_Shift_is_less_than_or_equal_to_max_req
    groupbyLevels = ['id_of_Shift']
    groupby_ResourceAssignment = list_of_ResourceAssignment.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    join_ResourceAssignment = groupby_ResourceAssignment.join(list_of_Shift.max_req, how='inner')
    for row in join_ResourceAssignment[join_ResourceAssignment.max_req.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAssignmentVar <= row.max_req, u'The number of Employees assigned to each Shift is less than or equal to max req', row)
    
    # [ST_2] Constraint : cResourceAssignmentCategoryCompatibilityConstraintOnPair#1_cCategoryCompatibilityConstraintOnPair
    # For each Employee-Shift assignment, requested skills of assigned Shift is included in skills of assigned Employees
    # Label: CT_2_For_each_Employee_Shift_assignment__requested_skills_of_assigned_Shift_is_included_in_skills_of_assigned_Employees
    join_Employee = list_of_Employee.join(list_of_Employee_skills.skills, how='inner')
    join_ResourceAssignment = list_of_ResourceAssignment.reset_index().set_index(['id_of_Employee']).join(join_Employee.skills, how='inner').reset_index().set_index(['id_of_Employee', 'id_of_Shift'])
    join_ResourceAssignment_2 = list_of_ResourceAssignment.join(list_of_Shift.requested_skills, how='inner')
    join_ResourceAssignment_3 = join_ResourceAssignment.reset_index().merge(join_ResourceAssignment_2.reset_index()[['id_of_Employee', 'id_of_Shift', 'requested_skills']], left_on=['id_of_Employee', 'id_of_Shift'], right_on=['id_of_Employee', 'id_of_Shift'], how='inner').set_index(['id_of_Employee', 'id_of_Shift'])
    filtered_ResourceAssignment = join_ResourceAssignment_3[join_ResourceAssignment_3.skills == join_ResourceAssignment_3.requested_skills].copy()
    helper_add_labeled_cplex_constraint(mdl, mdl.sum(join_ResourceAssignment_2.resourceAssignmentVar[(join_ResourceAssignment_2.requested_skills.notnull()) & (~join_ResourceAssignment_2.index.isin(filtered_ResourceAssignment.index.values))]) == 0, u'For each Employee-Shift assignment, requested skills of assigned Shift is included in skills of assigned Employees')
    
    # [ST_3] Constraint : cResourceAssignmentCategoryCompatibilityConstraintOnPair#2_cCategoryCompatibilityConstraintOnPair
    # For each Employee-Shift assignment, day of assigned Shift is disjoint from days off of assigned Employees
    # Label: CT_3_For_each_Employee_Shift_assignment__day_of_assigned_Shift_is_disjoint_from_days_off_of_assigned_Employees
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.day, how='inner')
    join_Employee = list_of_Employee.join(list_of_Employee_days_off.days_off, how='inner')
    join_ResourceAssignment_2 = list_of_ResourceAssignment.reset_index().set_index(['id_of_Employee']).join(join_Employee.days_off, how='inner').reset_index().set_index(['id_of_Employee', 'id_of_Shift'])
    join_ResourceAssignment_3 = join_ResourceAssignment.reset_index().merge(join_ResourceAssignment_2.reset_index()[['id_of_Employee', 'id_of_Shift', 'days_off']], left_on=['id_of_Employee', 'id_of_Shift'], right_on=['id_of_Employee', 'id_of_Shift'], how='inner').set_index(['id_of_Employee', 'id_of_Shift'])
    join_ResourceAssignment_3 = join_ResourceAssignment_3[(~join_ResourceAssignment_3.day.isnull()) & (~join_ResourceAssignment_3.days_off.isnull()) & (join_ResourceAssignment_3.day == join_ResourceAssignment_3.days_off)]
    helper_add_labeled_cplex_constraint(mdl, mdl.sum(join_ResourceAssignment_3.resourceAssignmentVar) == 0, u'For each Employee-Shift assignment, day of assigned Shift is disjoint from days off of assigned Employees')
    
    # [ST_4] Constraint : cIterativeRelationalConstraint#1_cIterativeRelationalConstraint
    # For each Employee-Day combination, number of associated Employee-Shift assignments is less than or equal to 1
    # Label: CT_4_For_each_Employee_Day_combination__number_of_associated_Employee_Shift_assignments_is_less_than_or_equal_to_1
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.day, how='inner')
    join___CombinationOf__Employee__Day_ = list_of___CombinationOf__Employee__Day_[[]].reset_index().merge(join_ResourceAssignment.reset_index(), left_on=['id_of_Employee', 'id_of_Day'], right_on=['id_of_Employee', 'day']).set_index(['id_of_Employee', 'id_of_Day', 'id_of_Shift'])
    groupbyLevels = ['id_of_Employee', 'id_of_Day']
    groupby___CombinationOf__Employee__Day_ = join___CombinationOf__Employee__Day_.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby___CombinationOf__Employee__Day_.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAssignmentVar <= 1, u'For each Employee-Day combination, number of associated Employee-Shift assignments is less than or equal to 1', row)
    
    # [ST_5] Constraint : cIterativeRelationalConstraint#2_cIterativeRelationalConstraint
    # For each Day, number of OnCallDuties is equal to on-call requirement
    # Label: CT_5_For_each_Day__number_of_OnCallDuties_is_equal_to_on_call_requirement
    groupbyLevels = ['id_of_Day']
    groupby_OnCallDuty = list_of_OnCallDuty.onCallDutyVar.groupby(level=groupbyLevels).sum().to_frame()
    join_OnCallDuty = groupby_OnCallDuty.join(list_of_Day.oncall_requirement, how='inner')
    for row in join_OnCallDuty[join_OnCallDuty.oncall_requirement.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.onCallDutyVar == row.oncall_requirement, u'For each Day, number of OnCallDuties is equal to on-call requirement', row)
    
    # [ST_6] Constraint : cIterativeImplyRelationalConstraint#1_cIterativeLogicalRelationalConstraint
    # For each Employee-Day combination,  if (number of associated Employee-Shift assignments is equal to 0) then (number of associated OnCallDuties is equal to 0)
    # Label: CT_6_For_each_Employee_Day_combination___if__number_of_associated_Employee_Shift_assignments_is_equal_to_0__then__number_of_associated_OnCallDuties_is_equal_to_0_
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.day, how='inner')
    join___CombinationOf__Employee__Day_ = list_of___CombinationOf__Employee__Day_[[]].reset_index().merge(join_ResourceAssignment.reset_index(), left_on=['id_of_Employee', 'id_of_Day'], right_on=['id_of_Employee', 'day']).set_index(['id_of_Employee', 'id_of_Day', 'id_of_Shift'])
    groupbyLevels = ['id_of_Employee', 'id_of_Day']
    groupby___CombinationOf__Employee__Day_ = join___CombinationOf__Employee__Day_.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    join___CombinationOf__Employee__Day__2 = list_of___CombinationOf__Employee__Day_[[]].reset_index().merge(list_of_OnCallDuty.reset_index(), left_on=['id_of_Employee', 'id_of_Day'], right_on=['id_of_Employee', 'id_of_Day']).set_index(['id_of_Employee', 'id_of_Day'])
    groupbyLevels_2 = ['id_of_Employee', 'id_of_Day']
    groupby___CombinationOf__Employee__Day__2 = join___CombinationOf__Employee__Day__2.onCallDutyVar.groupby(level=groupbyLevels_2).sum().to_frame()
    join___CombinationOf__Employee__Day__3 = groupby___CombinationOf__Employee__Day_.reset_index().merge(groupby___CombinationOf__Employee__Day__2.reset_index()[['id_of_Employee', 'id_of_Day', 'onCallDutyVar']], left_on=['id_of_Employee', 'id_of_Day'], right_on=['id_of_Employee', 'id_of_Day'], how='inner').set_index(['id_of_Employee', 'id_of_Day'])
    for row in join___CombinationOf__Employee__Day__3.itertuples(index=True):
        rhs_1_int = int(1000 * (0))
        helper_add_labeled_cplex_constraint(mdl, mdl.if_then(1000 * (row.resourceAssignmentVar) == rhs_1_int, row.onCallDutyVar == 0), u'For each Employee-Day combination,  if (number of associated Employee-Shift assignments is equal to 0) then (number of associated OnCallDuties is equal to 0)', row)
    
    # [ST_7] Constraint : limitConsecutiveAssignments15
    # No Employees is OnCallDuties more than 2 consecutive days
    # Label: CT_7_No_Employees_is_OnCallDuties_more_than_2_consecutive_days
    # -- # Data Structure for parameter: employees   --------------------
    # -- # DataFrame: Employee
    # -- # PrimaryKey  : id_of_Employee
    # -- #             : pay rate
    # -- #             : qualification
    # -- #             : seniority
    # -- #
    # -- # Data Structure for parameter: on_call_duties   --------------------
    # -- # DataFrame: OnCallDuty
    # -- # PrimaryKey  : id_of_Day
    # -- # PrimaryKey  : id_of_Employee
    # -- # DecisionVar : onCallDutyVar
    # -- #
    custom_code.limitConsecutiveAssignments(mdl, Employee, OnCallDuty, 2)


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    if mdl.get_solve_status() == JobSolveStatus.UNKNOWN:
        print('UNKNOWN cause: %s' % mdl.get_solve_details().status)
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('Internal constraint', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = pd.concat([list_of_conflicts, pd.DataFrame({'constraint': [label], 'context': [str(context)], 'detail': [ct]})],
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_OnCallDuty_solution = pd.DataFrame(index=list_of_OnCallDuty.index)
    list_of_OnCallDuty_solution['onCallDutyVar'] = msol.get_values(list_of_OnCallDuty.onCallDutyVar.values)
    list_of_ResourceAssignment_solution = pd.DataFrame(index=list_of_ResourceAssignment.index)
    list_of_ResourceAssignment_solution['resourceAssignmentVar'] = msol.get_values(list_of_ResourceAssignment.resourceAssignmentVar.values)
    AssignedShifts = pd.DataFrame(index=list_of_ResourceAssignment.index)
    
    # Adding extra columns based on Solution Schema
    groupbyLevels = ['id_of_Employee', 'id_of_Shift']
    groupby_ResourceAssignment = list_of_ResourceAssignment_solution.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    AssignedShifts['Employee assignments'] = groupby_ResourceAssignment['resourceAssignmentVar']
    groupbyLevels = ['id_of_Employee', 'id_of_Shift']
    groupby_ResourceAssignment = list_of_ResourceAssignment_solution.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    AssignedShifts['Shift assignments'] = groupby_ResourceAssignment['resourceAssignmentVar']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Employee.seniority, how='inner')
    AssignedShifts['Employee seniority'] = join_ResourceAssignment['seniority']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Employee.qualification, how='inner')
    AssignedShifts['Employee qualification'] = join_ResourceAssignment['qualification']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Employee.pay_rate, how='inner')
    AssignedShifts['Employee pay rate'] = join_ResourceAssignment['pay_rate']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.start_time, how='inner')
    AssignedShifts['Shift start time'] = join_ResourceAssignment['start_time']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.requested_skills, how='inner')
    AssignedShifts['Shift requested skills'] = join_ResourceAssignment['requested_skills']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.min_req, how='inner')
    AssignedShifts['Shift min req'] = join_ResourceAssignment['min_req']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.max_req, how='inner')
    AssignedShifts['Shift max req'] = join_ResourceAssignment['max_req']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.end_time, how='inner')
    AssignedShifts['Shift end time'] = join_ResourceAssignment['end_time']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.duration, how='inner')
    AssignedShifts['Shift duration'] = join_ResourceAssignment['duration']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.department, how='inner')
    AssignedShifts['Shift department'] = join_ResourceAssignment['department']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.day_index, how='inner')
    AssignedShifts['Shift day index'] = join_ResourceAssignment['day_index']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.day, how='inner')
    AssignedShifts['Shift day'] = join_ResourceAssignment['day']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.Week_start, how='inner')
    AssignedShifts['Shift Week start'] = join_ResourceAssignment['Week_start']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.Start_date, how='inner')
    AssignedShifts['Shift Start date'] = join_ResourceAssignment['Start_date']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Shift.End_date, how='inner')
    AssignedShifts['Shift End date'] = join_ResourceAssignment['End_date']
    AssignedShifts = AssignedShifts.round({'Employee assignments': 2, 'Shift assignments': 2})
    
    AssignedShifts['_INTERNAL_resourceAssignmentVar'] = list_of_ResourceAssignment_solution.resourceAssignmentVar
    AssignedShifts = AssignedShifts[AssignedShifts._INTERNAL_resourceAssignmentVar > 0.5]
    AssignedShifts = AssignedShifts.drop('_INTERNAL_resourceAssignmentVar', axis='columns')

    OnCallDuty = pd.DataFrame(index=list_of_OnCallDuty.index)
    OnCallDuty['OnCallDuty decision'] = list_of_OnCallDuty_solution['onCallDutyVar']
    join_OnCallDuty = list_of_OnCallDuty.join(list_of_Day.oncall_requirement, how='inner')
    OnCallDuty['Day on-call requirement'] = join_OnCallDuty['oncall_requirement']
    join_OnCallDuty = list_of_OnCallDuty.join(list_of_Day.index_, how='inner')
    OnCallDuty['Day index'] = join_OnCallDuty['index_']
    join_OnCallDuty = list_of_OnCallDuty.join(list_of_Employee.seniority, how='inner')
    OnCallDuty['Employee seniority'] = join_OnCallDuty['seniority']
    join_OnCallDuty = list_of_OnCallDuty.join(list_of_Employee.qualification, how='inner')
    OnCallDuty['Employee qualification'] = join_OnCallDuty['qualification']
    join_OnCallDuty = list_of_OnCallDuty.join(list_of_Employee.pay_rate, how='inner')
    OnCallDuty['Employee pay rate'] = join_OnCallDuty['pay_rate']
    
    OnCallDuty['_INTERNAL_onCallDutyVar'] = list_of_OnCallDuty_solution.onCallDutyVar
    OnCallDuty = OnCallDuty[OnCallDuty._INTERNAL_onCallDutyVar > 0.5]
    OnCallDuty = OnCallDuty.drop('_INTERNAL_onCallDutyVar', axis='columns')


    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['AssignedShifts'] = AssignedShifts[['Employee assignments', 'Shift assignments', 'Employee seniority', 'Employee qualification', 'Employee pay rate', 'Shift start time', 'Shift requested skills', 'Shift min req', 'Shift max req', 'Shift end time', 'Shift duration', 'Shift department', 'Shift day index', 'Shift day', 'Shift Week start', 'Shift Start date', 'Shift End date']].reset_index().rename(columns= {'id_of_Shift': 'Shift', 'id_of_Employee': 'Employee'})
        outputs['OnCallDuty'] = OnCallDuty[['OnCallDuty decision', 'Day on-call requirement', 'Day index', 'Employee seniority', 'Employee qualification', 'Employee pay rate']].reset_index().rename(columns= {'id_of_Employee': 'Employee', 'id_of_Day': 'Day'})
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Instantiate CustomCode class if definition exists
try:
    custom_code = CustomCode(globals())
except NameError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()


from docplex.mp.progress import ProgressListener
from docplex.util.environment import add_abort_callback, remove_abort_callback
from functools import partial


class SolutionListener(ProgressListener):
    def __init__(self):
        super(SolutionListener, self).__init__()
        self._cpx_incumbent_sol = None

    def requires_solution(self):
        return True

    def notify_solution(self, cpx_incumbent_sol):
        self._cpx_incumbent_sol = cpx_incumbent_sol


def save_and_write_last_solution_callback(sol_listener, outputs):
    if sol_listener._cpx_incumbent_sol:
        export_solution(sol_listener._cpx_incumbent_sol)
    write_all_outputs(outputs)


solution_listener = SolutionListener()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

#
model.add_progress_listener(solution_listener)
env = get_environment()
# Remove default abort callbacks
for cb in env.abort_callbacks:
    remove_abort_callback(cb)
# Add new abort callback to store latest found solution, if any
add_abort_callback(partial(save_and_write_last_solution_callback, solution_listener, outputs))

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
