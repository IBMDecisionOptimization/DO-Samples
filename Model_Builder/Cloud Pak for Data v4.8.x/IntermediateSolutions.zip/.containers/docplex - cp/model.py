from docplex.cp.model import CpoModel
from docplex.cp.solver.solver_listener import CpoSolverListener
from sys import stdout


#-----------------------------------------------------------------------------
# Initialize the problem data
#-----------------------------------------------------------------------------

# Transition costs between configurations.
# Tuple (A, B, TCost) means that the cost of  modifying the truck from configuration A to configuration B is TCost
CONFIGURATION_TRANSITION_COST = list(inputs['configurationTransitionCost'].itertuples(index=False, name=None))

# Compatibility between the product types and the configuration of the truck
# allowedContainerConfigs[i] = the array of all the configurations that accept products of type i
ALLOWED_CONTAINER_CONFIGS = list( tuple(x[1]) for x in inputs['allowedConfigs'].groupby("product_type", as_index=False).agg(list).itertuples(index=False, name=None) )

#-----------------------------------------------------------------------------
# Prepare the data for modeling
#-----------------------------------------------------------------------------
nbTruckConfigs = len(inputs['truckConfigurations'].index)
maxTruckConfigLoad = [config.load for config in inputs['truckConfigurations'].itertuples()]
truckCost = [config.cost for config in inputs['truckConfigurations'].itertuples()]
maxLoad = max(maxTruckConfigLoad)

nbOrders = len(inputs['orders'].index)
nbCustomers = 1 + max(order.customer_id for order in inputs['orders'].itertuples())
volumes = [order.volume for order in inputs['orders'].itertuples()]
productType = [order.product_type for order in inputs['orders'].itertuples()]

# Max number of truck deliveries (estimated upper bound, to be increased if no solution)
maxDeliveries = 15


#-----------------------------------------------------------------------------
# Implement a CpoSolverListener to save and publish solution tables.
#-----------------------------------------------------------------------------
import pandas as pd
def build_solution(msol, index):
    if msol.is_solution():
        solution=[]
        for i in range(maxDeliveries):
            ld = msol.get_value(load[i])
            if ld > 0:
                for j in range(nbOrders):
                    if (msol.get_value(where[j]) == i):
                        solution.append((index, i, msol.get_value(truckConfigs[i]), j, productType[j], volumes[j]))

        outputs['solution'] = pd.DataFrame(solution, columns=["iteration", "delivery", "config", "order", "product", "volume"])

class MyListener(CpoSolverListener):
    def __init__(self):
        CpoSolverListener.__init__(self)
        self.index = -1
        
    def result_found(self, solver, msol):
        self.index +=1
        build_solution(msol, self.index)
        #  `write_all_outputs()` will publish tables from outputs dictionnary as solution tables
        write_all_outputs(outputs)

#-----------------------------------------------------------------------------
# Build the model
#-----------------------------------------------------------------------------

# Create CPO model
mdl = CpoModel()

# To obtain tables for intermediate solutions, you must add a CpoSolverListener
# so that you can then create solution tables and publish them.
mdl.add_solver_listener(MyListener())


# Configuration of the truck for each delivery
truckConfigs = mdl.integer_var_list(maxDeliveries, 0, nbTruckConfigs - 1, "truckConfigs")
# In which delivery is an order
where = mdl.integer_var_list(nbOrders, 0, maxDeliveries - 1, "where")
# Load of a truck
load = mdl.integer_var_list(maxDeliveries, 0, maxLoad, "load")
# Number of deliveries that are required
nbDeliveries = mdl.integer_var(0, maxDeliveries)
# Identification of which customer is assigned to a delivery
customerOfDelivery = mdl.integer_var_list(maxDeliveries, 0, nbCustomers, "customerOfTruck")
# Transition cost for each delivery
transitionCost = mdl.integer_var_list(maxDeliveries - 1, 0, 1000, "transitionCost")

# transitionCost[i] = transition cost between configurations i and i+1
for i in range(1, maxDeliveries):
    auxVars = (truckConfigs[i - 1], truckConfigs[i], transitionCost[i - 1])
    mdl.add(mdl.allowed_assignments(auxVars, CONFIGURATION_TRANSITION_COST))

# Constrain the volume of the orders in each truck
mdl.add(mdl.pack(load, where, volumes, nbDeliveries))
for i in range(0, maxDeliveries):
    mdl.add(load[i] <= mdl.element(truckConfigs[i], maxTruckConfigLoad))

# Compatibility between the product type of an order and the configuration of its truck
for j in range(0, nbOrders):
    configOfContainer = mdl.integer_var(ALLOWED_CONTAINER_CONFIGS[productType[j]])
    mdl.add(configOfContainer == mdl.element(truckConfigs, where[j]))

# Only one customer per delivery
for j in range(0, nbOrders):
    mdl.add(mdl.element(customerOfDelivery, where[j]) == inputs['orders'].iloc[j].customer_id)

# Non-used deliveries are at the end
for j in range(1, maxDeliveries):
    mdl.add((load[j - 1] > 0) | (load[j] == 0))

# Dominance: the non used deliveries keep the last used configuration
mdl.add(load[0] > 0)
for i in range(1, maxDeliveries):
    mdl.add((load[i] > 0) | (truckConfigs[i] == truckConfigs[i - 1]))

# Dominance: regroup deliveries with same configuration
for i in range(maxDeliveries - 2, 0, -1):
    ct = mdl.logical_and([(truckConfigs[p] != truckConfigs[i - 1]) for p in range(i + 1, maxDeliveries)])
    mdl.add((truckConfigs[i] == truckConfigs[i - 1]) | ct)

# Objective: first criterion for minimizing the cost for configuring and loading trucks
#            second criterion for minimizing the number of deliveries
cost = sum(transitionCost) + sum(mdl.element(truckConfigs[i], truckCost) * (load[i] != 0) for i in range(maxDeliveries))
mdl.add(mdl.minimize_static_lex([cost, nbDeliveries]))

mdl.add_kpi(cost, "cost")
mdl.add_kpi(nbDeliveries, "nbDeliveries")
  
# Search strategy: first assign order to truck
mdl.set_search_phases([mdl.search_phase(where)])


#-----------------------------------------------------------------------------
# Solve the model and display the result
#-----------------------------------------------------------------------------

# Solve model
print("\nSolving model....")
for msol in mdl.start_search(TimeLimit=300, LogPeriod=3000):
    pass

# Print solution
if msol.is_solution():
    print("Solution: ")
    ovals = msol.get_objective_values()
    print('   Configuration cost: {}, number of deliveries: {}, items='.format(ovals[0], ovals[1]))
    for i in range(maxDeliveries):
        ld = msol.get_value(load[i])
        if ld > 0:
            print("   Delivery {:2d}: config={}".format(i,msol.get_value(truckConfigs[i])))
            print()
            for j in range(nbOrders):
                if (msol.get_value(where[j]) == i):
                    print(" <{}, {}, {}>".format(j, productType[j], volumes[j]), end="")
            print('\n')
else:
    print("Solve status: {}\n".format(msol.get_solve_status()))

build_solution(msol, "last")