from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys

# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


from pandas.api.types import is_string_dtype


def helper_check_data_type(df, column, df_label, check_type):
    if not column in df.columns:
        print('Column "%s" does not exist in table "%s"' % (column, df_label))
        return False
    non_nan_values = df[column][~df[column].isnull()]
    if check_type == 'INTEGER':
        k = non_nan_values.dtype.kind
        if k != 'i':
            if k == 'f':
                non_integer_values = non_nan_values.values[np.where([not x.is_integer() for x in non_nan_values])]
                if len(non_integer_values) > 0:
                    print('Column "%s" of table "%s" contains non-integer value(s) which violates expected type: %s' % (column, df_label, non_integer_values))
                    return False
            else:
                print('Column "%s" of table "%s" is non-numeric which violates expected type: %s' % (column, df_label, non_nan_values.values))
                return False
    elif check_type == 'FLOAT' or check_type == 'NUMBER':
        non_float_values = non_nan_values.values[np.where([not isinstance(x, (int, float)) for x in non_nan_values])]
        k = non_nan_values.dtype.kind
        if not k in ['i', 'f']:
            print('Column "%s" of table "%s" contains non-float value(s) which violates expected type: %s' % (column, df_label, non_float_values))
            return False
    elif check_type == 'BOOLEAN':
        non_bool_values = non_nan_values.values[np.where([not isinstance(x, bool) and not x in [0, 1] for x in non_nan_values])]
        if len(non_bool_values) > 0:
            print('Column "%s" of table "%s" contains non-boolean value(s) which violates expected type: %s' % (column, df_label, non_bool_values))
            return False
    elif check_type == 'Date' or check_type == 'DateTime':
        try:
            pd.to_datetime(non_nan_values)
        except ValueError as e:
            print('Column "%s" of table "%s" cannot be converted to a DateTime : %s' % (column, df_label, str(e)))
            return False
    elif check_type == 'Time':
        try:
            pd.to_timedelta(non_nan_values)
        except ValueError as e:
            try:
                # Try appending ':00' in case seconds are not represented in time
                pd.to_timedelta(non_nan_values + ':00')
            except ValueError as e:
                print('Column "%s" of table "%s" cannot be converted to a Time : %s' % (column, df_label, str(e)))
                return False
    elif check_type == 'STRING':
        if not is_string_dtype(non_nan_values):
            print('Column "%s" of table "%s" is not of type "String"' % (column, df_label))
            return False
    else:
        raise Exception('Invalid check_type: %s' % check_type)
    return True


def helper_check_foreignKey_values(source_df, source_column, source_df_label, target_df, target_column, target_df_label):
    non_nan_values = source_df[source_column][~source_df[source_column].isnull()]
    invalid_FK_values = non_nan_values[~non_nan_values.isin(target_df[target_column])].values
    if len(invalid_FK_values) > 0:
        print('FK Column "%s" of table "%s" contains values that do not exist in PK column "%s" of target table "%s": %s' % (source_column, source_df_label, target_column, target_df_label, invalid_FK_values))
        return False
    return True


def helper_check_unique_primaryKey_values(df, key_cols, df_label):
    df_grp = df.groupby(key_cols).size()
    invalid_pk_values = df_grp[df_grp > 1].reset_index()[key_cols].values
    if len(invalid_pk_values) > 0:
        print('Non-unique values for PK of table "%s": %s' % (df_label, invalid_pk_values))
        return False
    return True


# Return index values of a multi-index from index name
def helper_get_level_values(df, column_name):
    return df.index.get_level_values(df.index.names.index(column_name))

# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'Region': ['id_of_Region'],
    'cCustomerInventory': ['id_of_Market', 'id_of_Month', 'id_of_Product'],
    'cCustomerInventory__market__month__product__': ['id_of_Market', 'id_of_Month', 'id_of_Product'],
    'cDelivery': ['id_of_Market', 'id_of_Month', 'id_of_Plant', 'id_of_Product'],
    'cDelivery__plant__market__month__product__': ['id_of_Market', 'id_of_Month', 'id_of_Plant', 'id_of_Product'],
    'cDemand': ['id_of_Demand', 'id_of_Firm_sales'],
    'cExecutedSales': ['id_of_Market', 'id_of_Month', 'id_of_Product'],
    'cExecutedSales__market__month__product__': ['id_of_Market', 'id_of_Month', 'id_of_Product'],
    'cInitialCustomerInventory': ['id_of_Initial_inventory'],
    'cInventory': ['id_of_Month', 'id_of_Plant', 'id_of_Product'],
    'cInventory__plant__month__product__': ['id_of_Month', 'id_of_Plant', 'id_of_Product'],
    'cLocation': ['id_of_Plant'],
    'cPlanningCustomer': ['id_of_Market'],
    'cProduct': ['id_of_Product'],
    'cProduction': ['id_of_Month', 'id_of_Plant', 'id_of_Product'],
    'cProductionCost': ['id_of_Plant_product_cost'],
    'cProductionLimit': ['id_of_Plant_product_capacity'],
    'cProduction__plant__month__product__': ['id_of_Month', 'id_of_Plant', 'id_of_Product'],
    'cSalesProfit': ['id_of_Marginal_profit'],
    'cTimeBucket': ['id_of_Month'],
    'demand': ['id_of_Demand'],
    'firm_sales': ['id_of_Firm_sales'],
    'initial_inventory': ['id_of_Initial_inventory'],
    'marginal_profit': ['id_of_Marginal_profit'],
    'market': ['id_of_Market'],
    'month': ['id_of_Month'],
    'parameters': ['id_of_Parameters'],
    'plant': ['id_of_Plant'],
    'plant_month_capacity': ['id_of_Plant_month_capacity'],
    'plant_product_capacity': ['id_of_Plant_product_capacity'],
    'plant_product_cost': ['id_of_Plant_product_cost'],
    'product': ['id_of_Product']}
helper_property_id_to_column_names_map = {
    'cDemand.customer': 'Market',
    'cDemand.period': 'Month',
    'cDemand.product': 'Product',
    'cDemand.quantity': 'Value',
    'cInitialCustomerInventory.customer': 'Market',
    'cInitialCustomerInventory.product': 'Product',
    'cInitialCustomerInventory.quantity': 'Value',
    'cProductionCost.cost': 'Value',
    'cProductionCost.location': 'Plant',
    'cProductionCost.product': 'Product',
    'cProductionLimit.limit': 'Value',
    'cProductionLimit.location': 'Plant',
    'cProductionLimit.product': 'Product',
    'cSalesProfit.customer': 'Market',
    'cSalesProfit.period': 'Month',
    'cSalesProfit.product': 'Product',
    'cSalesProfit.profit': 'Value',
    'cTimeBucket.next': 'Next',
    'demand.Market': 'Market',
    'demand.Month': 'Month',
    'demand.Product': 'Product',
    'demand.Value': 'Value',
    'firm_sales.Market': 'Market',
    'firm_sales.Month': 'Month',
    'firm_sales.Product': 'Product',
    'firm_sales.Value': 'Value',
    'initial_inventory.Market': 'Market',
    'initial_inventory.Product': 'Product',
    'initial_inventory.Value': 'Value',
    'marginal_profit.Market': 'Market',
    'marginal_profit.Month': 'Month',
    'marginal_profit.Product': 'Product',
    'marginal_profit.Value': 'Value',
    'market.Region': 'Region',
    'month.Index': 'Index',
    'month.Next': 'Next',
    'month.Quarter': 'Quarter',
    'parameters.first_month': 'first_month',
    'plant_month_capacity.Month': 'Month',
    'plant_month_capacity.Plant': 'Plant',
    'plant_month_capacity.Value': 'Value',
    'plant_product_capacity.Plant': 'Plant',
    'plant_product_capacity.Product': 'Product',
    'plant_product_capacity.Value': 'Value',
    'plant_product_cost.Plant': 'Plant',
    'plant_product_cost.Product': 'Product',
    'plant_product_cost.Value': 'Value',
    'product.Maturity': 'Maturity',
    'product.Price Level': 'Price_Level',
    'product.Type': 'Type'}


# Data model definition for each table
# Data collection: list_of_Region ['id']
# Data collection: list_of_Demand ['Market', 'Month', 'Product', 'Value', '__line']
# Data collection: list_of_Firm_sales ['Market', 'Month', 'Product', 'Value', '__line']
# Data collection: list_of_Initial_inventory ['Market', 'Product', 'Value', '__line']
# Data collection: list_of_Marginal_profit ['Market', 'Month', 'Product', 'Value', '__line']
# Data collection: list_of_Market ['Region', 'Name']
# Data collection: list_of_Month ['Next', 'Quarter', 'Name', 'Index']
# Data collection: list_of_Parameters ['first_month', 'ID']
# Data collection: list_of_Plant ['Name']
# Data collection: list_of_Plant_month_capacity ['Value', 'Plant', 'Month', '__line']
# Data collection: list_of_Plant_product_capacity ['Plant', 'Product', 'Value', '__line']
# Data collection: list_of_Plant_product_cost ['Plant', 'Product', 'Value', '__line']
# Data collection: list_of_Product ['Type', 'Price_Level', 'Name', 'Maturity']

# Create a pandas Dataframe for each data table
list_of_Demand = inputs[u'demand']
list_of_Demand = list_of_Demand[[u'Market', u'Month', u'Product', u'Value']].copy()
list_of_Demand.rename(columns={u'Market': 'Market', u'Month': 'Month', u'Product': 'Product', u'Value': 'Value'}, inplace=True)
list_of_Firm_sales = inputs[u'firm_sales']
list_of_Firm_sales = list_of_Firm_sales[[u'Market', u'Month', u'Product', u'Value']].copy()
list_of_Firm_sales.rename(columns={u'Market': 'Market', u'Month': 'Month', u'Product': 'Product', u'Value': 'Value'}, inplace=True)
list_of_Initial_inventory = inputs[u'initial_inventory']
list_of_Initial_inventory = list_of_Initial_inventory[[u'Market', u'Product', u'Value']].copy()
list_of_Initial_inventory.rename(columns={u'Market': 'Market', u'Product': 'Product', u'Value': 'Value'}, inplace=True)
list_of_Marginal_profit = inputs[u'marginal_profit']
list_of_Marginal_profit = list_of_Marginal_profit[[u'Market', u'Month', u'Product', u'Value']].copy()
list_of_Marginal_profit.rename(columns={u'Market': 'Market', u'Month': 'Month', u'Product': 'Product', u'Value': 'Value'}, inplace=True)
list_of_Market = inputs[u'market']
list_of_Market = list_of_Market[[u'Region', u'Name']].copy()
list_of_Market.rename(columns={u'Region': 'Region', u'Name': 'Name'}, inplace=True)
list_of_Month = inputs[u'month']
list_of_Month = list_of_Month[[u'Next', u'Quarter', u'Name', u'Index']].copy()
list_of_Month.rename(columns={u'Next': 'Next', u'Quarter': 'Quarter', u'Name': 'Name', u'Index': 'Index'}, inplace=True)
list_of_Parameters = inputs[u'parameters']
list_of_Parameters = list_of_Parameters[[u'first_month', u'ID']].copy()
list_of_Parameters.rename(columns={u'first_month': 'first_month', u'ID': 'ID'}, inplace=True)
list_of_Plant = inputs[u'plant']
list_of_Plant = list_of_Plant[[u'Name']].copy()
list_of_Plant.rename(columns={u'Name': 'Name'}, inplace=True)
list_of_Plant_month_capacity = inputs[u'plant_month_capacity']
list_of_Plant_month_capacity = list_of_Plant_month_capacity[[u'Value', u'Plant', u'Month']].copy()
list_of_Plant_month_capacity.rename(columns={u'Value': 'Value', u'Plant': 'Plant', u'Month': 'Month'}, inplace=True)
list_of_Plant_product_capacity = inputs[u'plant_product_capacity']
list_of_Plant_product_capacity = list_of_Plant_product_capacity[[u'Plant', u'Product', u'Value']].copy()
list_of_Plant_product_capacity.rename(columns={u'Plant': 'Plant', u'Product': 'Product', u'Value': 'Value'}, inplace=True)
list_of_Plant_product_cost = inputs[u'plant_product_cost']
list_of_Plant_product_cost = list_of_Plant_product_cost[[u'Plant', u'Product', u'Value']].copy()
list_of_Plant_product_cost.rename(columns={u'Plant': 'Plant', u'Product': 'Product', u'Value': 'Value'}, inplace=True)
list_of_Product = inputs[u'product']
list_of_Product = list_of_Product[[u'Type', u'Price Level', u'Name', u'Maturity']].copy()
list_of_Product.rename(columns={u'Type': 'Type', u'Price Level': 'Price_Level', u'Name': 'Name', u'Maturity': 'Maturity'}, inplace=True)
# --- Handling table for implicit concept
list_of_Region = pd.DataFrame(inputs[u'market']['Region'].unique(), columns=['id']).dropna()

# Perform input data checking against schema configured in Modelling Assistant along with unicity of PK values
data_check_result = True
# --- Handling data checking for implicit concept: Region
# --- Handling data checking for table: demand
data_check_result &= helper_check_foreignKey_values(list_of_Demand, 'Market', 'demand', list_of_Market, 'Name', 'market')
data_check_result &= helper_check_foreignKey_values(list_of_Demand, 'Month', 'demand', list_of_Month, 'Name', 'month')
data_check_result &= helper_check_foreignKey_values(list_of_Demand, 'Product', 'demand', list_of_Product, 'Name', 'product')
data_check_result &= helper_check_data_type(list_of_Demand, 'Value', 'demand', 'NUMBER')
# --- Handling data checking for table: firm_sales
data_check_result &= helper_check_foreignKey_values(list_of_Firm_sales, 'Market', 'firm_sales', list_of_Market, 'Name', 'market')
data_check_result &= helper_check_foreignKey_values(list_of_Firm_sales, 'Month', 'firm_sales', list_of_Month, 'Name', 'month')
data_check_result &= helper_check_foreignKey_values(list_of_Firm_sales, 'Product', 'firm_sales', list_of_Product, 'Name', 'product')
data_check_result &= helper_check_data_type(list_of_Firm_sales, 'Value', 'firm_sales', 'NUMBER')
# --- Handling data checking for table: initial_inventory
data_check_result &= helper_check_foreignKey_values(list_of_Initial_inventory, 'Market', 'initial_inventory', list_of_Market, 'Name', 'market')
data_check_result &= helper_check_foreignKey_values(list_of_Initial_inventory, 'Product', 'initial_inventory', list_of_Product, 'Name', 'product')
data_check_result &= helper_check_data_type(list_of_Initial_inventory, 'Value', 'initial_inventory', 'NUMBER')
# --- Handling data checking for table: marginal_profit
data_check_result &= helper_check_foreignKey_values(list_of_Marginal_profit, 'Market', 'marginal_profit', list_of_Market, 'Name', 'market')
data_check_result &= helper_check_foreignKey_values(list_of_Marginal_profit, 'Month', 'marginal_profit', list_of_Month, 'Name', 'month')
data_check_result &= helper_check_foreignKey_values(list_of_Marginal_profit, 'Product', 'marginal_profit', list_of_Product, 'Name', 'product')
data_check_result &= helper_check_data_type(list_of_Marginal_profit, 'Value', 'marginal_profit', 'NUMBER')
# --- Handling data checking for table: market
data_check_result &= helper_check_foreignKey_values(list_of_Market, 'Region', 'market', list_of_Region, 'id', 'Region')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Market, ['Name'], 'market')
# --- Handling data checking for table: month
data_check_result &= helper_check_foreignKey_values(list_of_Month, 'Next', 'month', list_of_Month, 'Name', 'month')
data_check_result &= helper_check_data_type(list_of_Month, 'Index', 'month', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Month, ['Name'], 'month')
# --- Handling data checking for table: parameters
data_check_result &= helper_check_foreignKey_values(list_of_Parameters, 'first_month', 'parameters', list_of_Month, 'Name', 'month')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Parameters, ['ID'], 'parameters')
# --- Handling data checking for table: plant
data_check_result &= helper_check_unique_primaryKey_values(list_of_Plant, ['Name'], 'plant')
# --- Handling data checking for table: plant_month_capacity
data_check_result &= helper_check_data_type(list_of_Plant_month_capacity, 'Value', 'plant_month_capacity', 'NUMBER')
data_check_result &= helper_check_foreignKey_values(list_of_Plant_month_capacity, 'Plant', 'plant_month_capacity', list_of_Plant, 'Name', 'plant')
data_check_result &= helper_check_foreignKey_values(list_of_Plant_month_capacity, 'Month', 'plant_month_capacity', list_of_Month, 'Name', 'month')
# --- Handling data checking for table: plant_product_capacity
data_check_result &= helper_check_foreignKey_values(list_of_Plant_product_capacity, 'Plant', 'plant_product_capacity', list_of_Plant, 'Name', 'plant')
data_check_result &= helper_check_foreignKey_values(list_of_Plant_product_capacity, 'Product', 'plant_product_capacity', list_of_Product, 'Name', 'product')
data_check_result &= helper_check_data_type(list_of_Plant_product_capacity, 'Value', 'plant_product_capacity', 'NUMBER')
# --- Handling data checking for table: plant_product_cost
data_check_result &= helper_check_foreignKey_values(list_of_Plant_product_cost, 'Plant', 'plant_product_cost', list_of_Plant, 'Name', 'plant')
data_check_result &= helper_check_foreignKey_values(list_of_Plant_product_cost, 'Product', 'plant_product_cost', list_of_Product, 'Name', 'product')
data_check_result &= helper_check_data_type(list_of_Plant_product_cost, 'Value', 'plant_product_cost', 'NUMBER')
# --- Handling data checking for table: product
data_check_result &= helper_check_unique_primaryKey_values(list_of_Product, ['Name'], 'product')
if not data_check_result:
    # Stop execution here
    raise Exception('Data checking detected errors')

# Force column type for non-numeric columns
list_of_Region = list_of_Region.astype({'id': object})
list_of_Demand = list_of_Demand.astype({'Market': object, 'Month': object, 'Product': object})
list_of_Firm_sales = list_of_Firm_sales.astype({'Market': object, 'Month': object, 'Product': object})
list_of_Initial_inventory = list_of_Initial_inventory.astype({'Market': object, 'Product': object})
list_of_Marginal_profit = list_of_Marginal_profit.astype({'Market': object, 'Month': object, 'Product': object})
list_of_Market = list_of_Market.astype({'Region': object, 'Name': object})
list_of_Month = list_of_Month.astype({'Next': object, 'Quarter': object, 'Name': object})
list_of_Parameters = list_of_Parameters.astype({'first_month': object, 'ID': object})
list_of_Plant = list_of_Plant.astype({'Name': object})
list_of_Plant_month_capacity = list_of_Plant_month_capacity.astype({'Plant': object, 'Month': object})
list_of_Plant_product_capacity = list_of_Plant_product_capacity.astype({'Plant': object, 'Product': object})
list_of_Plant_product_cost = list_of_Plant_product_cost.astype({'Plant': object, 'Product': object})
list_of_Product = list_of_Product.astype({'Type': object, 'Price_Level': object, 'Name': object, 'Maturity': object})

# Set index when a primary key is defined
list_of_Region.set_index('id', inplace=True)
list_of_Region.sort_index(inplace=True)
list_of_Region.index.name = 'id_of_Region'
list_of_Demand.index.name = 'id_of_Demand'
list_of_Firm_sales.index.name = 'id_of_Firm_sales'
list_of_Initial_inventory.index.name = 'id_of_Initial_inventory'
list_of_Marginal_profit.index.name = 'id_of_Marginal_profit'
list_of_Market.set_index('Name', inplace=True)
list_of_Market.sort_index(inplace=True)
list_of_Market.index.name = 'id_of_Market'
list_of_Month.set_index('Name', inplace=True)
list_of_Month.sort_index(inplace=True)
list_of_Month.index.name = 'id_of_Month'
list_of_Parameters.set_index('ID', inplace=True)
list_of_Parameters.sort_index(inplace=True)
list_of_Parameters.index.name = 'id_of_Parameters'
list_of_Plant.set_index('Name', inplace=True)
list_of_Plant.sort_index(inplace=True)
list_of_Plant.index.name = 'id_of_Plant'
list_of_Plant_month_capacity.index.name = 'id_of_Plant_month_capacity'
list_of_Plant_product_capacity.index.name = 'id_of_Plant_product_capacity'
list_of_Plant_product_cost.index.name = 'id_of_Plant_product_cost'
list_of_Product.set_index('Name', inplace=True)
list_of_Product.sort_index(inplace=True)
list_of_Product.index.name = 'id_of_Product'


# Create data frame as cartesian product of: Plant x Month x Product
list_of_Production = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Plant.index, list_of_Month.index, list_of_Product.index), names=['id_of_Plant', 'id_of_Month', 'id_of_Product']))
# Create data frame as cartesian product of: Market x Month x Product
list_of_ExecutedSales = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Market.index, list_of_Month.index, list_of_Product.index), names=['id_of_Market', 'id_of_Month', 'id_of_Product']))
# Create data frame as cartesian product of: Market x Month x Product
list_of_CustomerInventory = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Market.index, list_of_Month.index, list_of_Product.index), names=['id_of_Market', 'id_of_Month', 'id_of_Product']))
# Create data frame as cartesian product of: Plant x Month x Product
list_of_Inventory = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Plant.index, list_of_Month.index, list_of_Product.index), names=['id_of_Plant', 'id_of_Month', 'id_of_Product']))
# Create data frame as cartesian product of: Plant x Market x Month x Product
list_of_Delivery = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Plant.index, list_of_Market.index, list_of_Month.index, list_of_Product.index), names=['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product']))






def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_Production['productionVar'] = mdl.continuous_var_list(len(list_of_Production))
    list_of_ExecutedSales['executedSalesVar'] = mdl.continuous_var_list(len(list_of_ExecutedSales))
    list_of_CustomerInventory['customerInventoryVar'] = mdl.continuous_var_list(len(list_of_CustomerInventory))
    list_of_Inventory['inventoryVar'] = mdl.continuous_var_list(len(list_of_Inventory))
    list_of_Delivery['deliveryVar'] = mdl.continuous_var_list(len(list_of_Delivery))



    # Definition of model
    # Objective cMaximizeExecutedSalesProfit-
    # Combine weighted criteria: 
    # 	cMaximizeExecutedSalesProfit cMaximizeExecutedSalesProfit 1.2{
    # 	executedSales = cExecutedSales__market__month__product__,
    # 	salesProfit = marginal_profit,
    # 	scaleFactorExpr = 1} with weight 5.0
    # 	cMinimizeProductionCost cMinimizeProductionCost 1.2{
    # 	production = cProduction__plant__month__product__,
    # 	productionCost = plant_product_cost,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = total plant_product_cost [plant_product_cost is joined to cProduction__plant__month__product__] / Value over cProduction} with weight 5.0
    # 	cMaximizeExecutedSales cMaximizeExecutedSales 1.2{
    # 	executedSales = cExecutedSales__market__month__product__,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) customer = market,
    # 	(static) numericExpr = decisionPath(cExecutedSales__market__month__product__)} with weight 5.0
    # 	cMinimizeTotalCustomerInventory cMinimizeTotalCustomerInventory 1.2{
    # 	customerInventory = cCustomerInventory__market__month__product__,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) customer = market,
    # 	(static) numericExpr = decisionPath(cCustomerInventory__market__month__product__)} with weight 5.0
    join_Marginal_profit_SG1 = list_of_Marginal_profit.reset_index().merge(list_of_ExecutedSales.reset_index(), left_on=['Market', 'Month', 'Product'], right_on=['id_of_Market', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Marginal_profit', 'id_of_Market', 'id_of_Month', 'id_of_Product'])
    groupby_Marginal_profit_SG1 = join_Marginal_profit_SG1.Value.groupby(level=['id_of_Market', 'id_of_Month', 'id_of_Product']).sum().to_frame()
    join_ExecutedSales_SG1 = list_of_ExecutedSales.reset_index().merge(groupby_Marginal_profit_SG1.reset_index(), left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Market', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Market', 'id_of_Month', 'id_of_Product'])
    join_ExecutedSales_SG1['conditioned_Value'] = join_ExecutedSales_SG1.executedSalesVar * join_ExecutedSales_SG1.Value
    agg_ExecutedSales_conditioned_Value_SG1 = mdl.sum(join_ExecutedSales_SG1.conditioned_Value)
    join_Plant_product_cost_SG2 = list_of_Plant_product_cost.reset_index().merge(list_of_Production.reset_index(), left_on=['Plant', 'Product'], right_on=['id_of_Plant', 'id_of_Product']).set_index(['id_of_Plant_product_cost', 'id_of_Plant', 'id_of_Month', 'id_of_Product'])
    groupby_Plant_product_cost_SG2 = join_Plant_product_cost_SG2.Value.groupby(level=['id_of_Plant', 'id_of_Month', 'id_of_Product']).sum().to_frame()
    join_Production_SG2 = list_of_Production.reset_index().merge(groupby_Plant_product_cost_SG2.reset_index(), left_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product'])
    join_Production_SG2['conditioned_Value'] = join_Production_SG2.productionVar * join_Production_SG2.Value
    agg_Production_conditioned_Value_SG2 = mdl.sum(join_Production_SG2.conditioned_Value)
    agg_ExecutedSales_executedSalesVar_SG3 = mdl.sum(list_of_ExecutedSales.executedSalesVar)
    agg_CustomerInventory_customerInventoryVar_SG4 = mdl.sum(list_of_CustomerInventory.customerInventoryVar)
    
    kpis_expression_list = [
        (-1, 16.0, agg_ExecutedSales_conditioned_Value_SG1, 1, 0, u'sales profit based on marginal_profit'),
        (1, 16.0, agg_Production_conditioned_Value_SG2, 1, 0, u'overall production cost based on plant_product_cost'),
        (-1, 16.0, agg_ExecutedSales_executedSalesVar_SG3, 1, 0, u'market sales'),
        (1, 16.0, agg_CustomerInventory_customerInventoryVar_SG4, 1, 0, u'total inventory at markets')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_expr, publish_name=kpi_name)
    
    mdl.minimize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cDecisionBoundsSetting#1_cIterativeRelationalConstraint
    # The value of any delivery decision is in range 0, 1000000000
    # Label: CT_1_The_value_of_any_delivery_decision_is_in_range_0__1000000000
    for row in list_of_Delivery.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.deliveryVar >= 0, u'The value of any delivery decision is in range 0, 1000000000', row)
    
    # [ST_2] Constraint : cDecisionBoundsSetting#1_cIterativeRelationalConstraint
    # The value of any delivery decision is in range 0, 1000000000
    # Label: CT_2_The_value_of_any_delivery_decision_is_in_range_0__1000000000
    for row in list_of_Delivery.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.deliveryVar <= 1000000000, u'The value of any delivery decision is in range 0, 1000000000', row)
    
    # [ST_3] Constraint : cDecisionBoundsSetting#2_cIterativeRelationalConstraint
    # The value of any executed sales decision is in range 0, 1000000000
    # Label: CT_3_The_value_of_any_executed_sales_decision_is_in_range_0__1000000000
    for row in list_of_ExecutedSales.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.executedSalesVar >= 0, u'The value of any executed sales decision is in range 0, 1000000000', row)
    
    # [ST_4] Constraint : cDecisionBoundsSetting#2_cIterativeRelationalConstraint
    # The value of any executed sales decision is in range 0, 1000000000
    # Label: CT_4_The_value_of_any_executed_sales_decision_is_in_range_0__1000000000
    for row in list_of_ExecutedSales.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.executedSalesVar <= 1000000000, u'The value of any executed sales decision is in range 0, 1000000000', row)
    
    # [ST_5] Constraint : cDecisionBoundsSetting#3_cIterativeRelationalConstraint
    # The value of any market inventory decision is in range 0, 1000000000
    # Label: CT_5_The_value_of_any_market_inventory_decision_is_in_range_0__1000000000
    for row in list_of_CustomerInventory.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.customerInventoryVar >= 0, u'The value of any market inventory decision is in range 0, 1000000000', row)
    
    # [ST_6] Constraint : cDecisionBoundsSetting#3_cIterativeRelationalConstraint
    # The value of any market inventory decision is in range 0, 1000000000
    # Label: CT_6_The_value_of_any_market_inventory_decision_is_in_range_0__1000000000
    for row in list_of_CustomerInventory.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.customerInventoryVar <= 1000000000, u'The value of any market inventory decision is in range 0, 1000000000', row)
    
    # [ST_7] Constraint : cDecisionBoundsSetting#4_cIterativeRelationalConstraint
    # The value of any plant inventory decision is in range 0, 1000000000
    # Label: CT_7_The_value_of_any_plant_inventory_decision_is_in_range_0__1000000000
    for row in list_of_Inventory.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.inventoryVar >= 0, u'The value of any plant inventory decision is in range 0, 1000000000', row)
    
    # [ST_8] Constraint : cDecisionBoundsSetting#4_cIterativeRelationalConstraint
    # The value of any plant inventory decision is in range 0, 1000000000
    # Label: CT_8_The_value_of_any_plant_inventory_decision_is_in_range_0__1000000000
    for row in list_of_Inventory.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.inventoryVar <= 1000000000, u'The value of any plant inventory decision is in range 0, 1000000000', row)
    
    # [ST_9] Constraint : cDecisionBoundsSetting#5_cIterativeRelationalConstraint
    # The value of any production decision is in range 0, 1000000000
    # Label: CT_9_The_value_of_any_production_decision_is_in_range_0__1000000000
    for row in list_of_Production.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.productionVar >= 0, u'The value of any production decision is in range 0, 1000000000', row)
    
    # [ST_10] Constraint : cDecisionBoundsSetting#5_cIterativeRelationalConstraint
    # The value of any production decision is in range 0, 1000000000
    # Label: CT_10_The_value_of_any_production_decision_is_in_range_0__1000000000
    for row in list_of_Production.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.productionVar <= 1000000000, u'The value of any production decision is in range 0, 1000000000', row)
    
    # [ST_11] Constraint : cProductConservationAtCustomer#1_cIterativeRelationalConstraint
    # Ensure product inventory conservation at markets considering sales and allocation
    # Label: CT_11_Ensure_product_inventory_conservation_at_markets_considering_sales_and_allocation
    join_Delivery = list_of_Delivery.reset_index().merge(list_of_ExecutedSales.reset_index(), left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Market', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product'])
    groupbyLevels = ['id_of_Market', 'id_of_Month', 'id_of_Product']
    groupby_Delivery = join_Delivery.deliveryVar.groupby(level=groupbyLevels).sum().to_frame()
    join_CustomerInventory = list_of_CustomerInventory.reset_index().merge(list_of_ExecutedSales.reset_index(), left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Market', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Market', 'id_of_Month', 'id_of_Product'])
    groupbyLevels = ['id_of_Market', 'id_of_Month', 'id_of_Product']
    groupby_CustomerInventory = join_CustomerInventory.customerInventoryVar.groupby(level=groupbyLevels).sum().to_frame()
    bin_op_merge = groupby_Delivery.deliveryVar.reset_index().join(groupby_CustomerInventory.customerInventoryVar.reset_index().set_index(['id_of_Market', 'id_of_Month', 'id_of_Product']), on=['id_of_Market', 'id_of_Month', 'id_of_Product'], how='outer').set_index(['id_of_Market', 'id_of_Month', 'id_of_Product']).fillna(0)
    bin_op_Delivery = pd.Series(bin_op_merge.deliveryVar + bin_op_merge.customerInventoryVar, name='result').to_frame()
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Month.Next, how='inner')
    join_CustomerInventory_2 = list_of_CustomerInventory.reset_index().merge(join_ExecutedSales.reset_index(), left_on=['id_of_Product', 'id_of_Market', 'id_of_Month'], right_on=['id_of_Product', 'id_of_Market', 'Next'], suffixes=('', '_right')).set_index(['id_of_Market', 'id_of_Month', 'id_of_Product', 'id_of_Month_right'])
    groupbyLevels_2 = ['id_of_Market', 'id_of_Product', 'id_of_Month_right']
    groupby_CustomerInventory_2 = join_CustomerInventory_2.customerInventoryVar.groupby(level=groupbyLevels_2).sum().to_frame()
    bin_op_merge = groupby_CustomerInventory_2.customerInventoryVar.reset_index().join(list_of_ExecutedSales.executedSalesVar.reset_index().set_index(['id_of_Market', 'id_of_Month', 'id_of_Product']), on=['id_of_Market', 'id_of_Month_right', 'id_of_Product'], how='outer').set_index(['id_of_Market', 'id_of_Product', 'id_of_Month_right']).fillna(0)
    bin_op_CustomerInventory = pd.Series(bin_op_merge.customerInventoryVar + bin_op_merge.executedSalesVar, name='result').to_frame()
    join_Delivery_2 = bin_op_Delivery.reset_index().merge(bin_op_CustomerInventory.reset_index()[['id_of_Market', 'id_of_Product', 'id_of_Month_right', 'result']], left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Market', 'id_of_Month_right', 'id_of_Product'], suffixes=('', '_right'), how='inner').set_index(['id_of_Market', 'id_of_Month', 'id_of_Product'])
    for row in join_Delivery_2.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.result == row.result_right, u'Ensure product inventory conservation at markets considering sales and allocation', row)
    
    # [ST_12] Constraint : cProductionDeliveryAssociation#1_cIterativeRelationalConstraint
    # The delivery quantities at markets must come from production and inventory at plants
    # Label: CT_12_The_delivery_quantities_at_markets_must_come_from_production_and_inventory_at_plants
    join_Delivery = list_of_Delivery.reset_index().merge(list_of_Production.reset_index(), left_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product'])
    groupbyLevels = ['id_of_Plant', 'id_of_Month', 'id_of_Product']
    groupby_Delivery = join_Delivery.deliveryVar.groupby(level=groupbyLevels).sum().to_frame()
    join_Inventory = list_of_Inventory.reset_index().merge(list_of_Production.reset_index(), left_on=['id_of_Product', 'id_of_Plant', 'id_of_Month'], right_on=['id_of_Product', 'id_of_Plant', 'id_of_Month']).set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product'])
    groupbyLevels = ['id_of_Plant', 'id_of_Month', 'id_of_Product']
    groupby_Inventory = join_Inventory.inventoryVar.groupby(level=groupbyLevels).sum().to_frame()
    join_Production = list_of_Production.join(list_of_Month.Next, how='inner')
    join_Inventory_2 = list_of_Inventory.reset_index().merge(join_Production.reset_index(), left_on=['id_of_Product', 'id_of_Plant', 'id_of_Month'], right_on=['id_of_Product', 'id_of_Plant', 'Next'], suffixes=('', '_right')).set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product', 'id_of_Month_right'])
    groupbyLevels_2 = ['id_of_Plant', 'id_of_Product', 'id_of_Month_right']
    groupby_Inventory_2 = join_Inventory_2.inventoryVar.groupby(level=groupbyLevels_2).sum().to_frame()
    bin_op_merge = groupby_Inventory.inventoryVar.reset_index().join(groupby_Inventory_2.inventoryVar.reset_index().set_index(['id_of_Plant', 'id_of_Product', 'id_of_Month_right']), on=['id_of_Plant', 'id_of_Product', 'id_of_Month'], rsuffix='_right', how='outer').set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product']).fillna(0)
    bin_op_Inventory = pd.Series(bin_op_merge.inventoryVar - bin_op_merge.inventoryVar_right, name='result').to_frame()
    bin_op_merge_2 = bin_op_Inventory.result.reset_index().join(list_of_Production.productionVar.reset_index().set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product']), on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], how='outer').set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product']).fillna(0)
    bin_op_Inventory_2 = pd.Series(bin_op_merge_2.result + bin_op_merge_2.productionVar, name='result').to_frame()
    join_Delivery_2 = groupby_Delivery.reset_index().merge(bin_op_Inventory_2.reset_index()[['id_of_Plant', 'id_of_Month', 'id_of_Product', 'result']], left_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], how='inner').set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product'])
    for row in join_Delivery_2.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.deliveryVar == row.result, u'The delivery quantities at markets must come from production and inventory at plants', row)
    
    # [ST_13] Constraint : cSetInitialCustomerInventory#1_cIterativeRelationalConstraint
    # Set the initial market inventory for first_month of parameters to initial_inventories
    # Label: CT_13_Set_the_initial_market_inventory_for_first_month_of_parameters_to_initial_inventories
    filtered_CustomerInventory = list_of_CustomerInventory.loc[helper_get_level_values(list_of_CustomerInventory, 'id_of_Month') == list_of_Parameters.first_month.iloc[0]].copy()
    join_Initial_inventory = list_of_Initial_inventory.reset_index().merge(list_of_CustomerInventory.reset_index(), left_on=['Market', 'Product'], right_on=['id_of_Market', 'id_of_Product']).set_index(['id_of_Initial_inventory', 'id_of_Market', 'id_of_Month', 'id_of_Product'])
    groupby_Initial_inventory = join_Initial_inventory.Value.groupby(level=['id_of_Market', 'id_of_Month', 'id_of_Product']).sum().to_frame()
    join_CustomerInventory = filtered_CustomerInventory.reset_index().merge(groupby_Initial_inventory.reset_index()[['id_of_Market', 'id_of_Month', 'id_of_Product', 'Value']], left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], how='inner').set_index(['id_of_Market', 'id_of_Month', 'id_of_Product'])
    for row in join_CustomerInventory[join_CustomerInventory.Value.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.customerInventoryVar == row.Value, u'Set the initial market inventory for first_month of parameters to initial_inventories', row)
    
    # [ST_14] Constraint : cEnforceIndividualProductionLimit#1_cIterativeRelationalConstraint
    # The production limit is defined by plant_product_capacity. It is same for each month.
    # Label: CT_14_The_production_limit_is_defined_by_plant_product_capacity__It_is_same_for_each_month_
    join_Plant_product_capacity = list_of_Plant_product_capacity.reset_index().merge(list_of_Production.reset_index(), left_on=['Plant', 'Product'], right_on=['id_of_Plant', 'id_of_Product']).set_index(['id_of_Plant_product_capacity', 'id_of_Plant', 'id_of_Month', 'id_of_Product'])
    groupby_Plant_product_capacity = join_Plant_product_capacity.Value.groupby(level=['id_of_Plant', 'id_of_Month', 'id_of_Product']).sum().to_frame()
    join_Production = list_of_Production.reset_index().merge(groupby_Plant_product_capacity.reset_index()[['id_of_Plant', 'id_of_Month', 'id_of_Product', 'Value']], left_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], how='inner').set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product'])
    for row in join_Production[join_Production.Value.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.productionVar <= row.Value, u'The production limit is defined by plant_product_capacity. It is same for each month.', row)
    
    # [ST_15] Constraint : cNonNegativeCustomerInventory#1_cIterativeRelationalConstraint
    # No negative inventory is possible at markets
    # Label: CT_15_No_negative_inventory_is_possible_at_markets
    for row in list_of_CustomerInventory.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.customerInventoryVar >= 0, u'No negative inventory is possible at markets', row)
    
    # [ST_16] Constraint : cInventoryConstraint#1_cIterativeRelationalConstraint
    # Ensure that level of each plant inventory is less than or equal to 0
    # Label: CT_16_Ensure_that_level_of_each_plant_inventory_is_less_than_or_equal_to_0
    for row in list_of_Inventory.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.inventoryVar <= 0, u'Ensure that level of each plant inventory is less than or equal to 0', row)
    
    # [ST_17] Constraint : cExecutedSalesBelowDemand#1_cIterativeRelationalConstraint
    # Sales are less than the planned demand
    # Label: CT_17_Sales_are_less_than_the_planned_demand
    join_ExecutedSales = list_of_ExecutedSales.reset_index().merge(list_of_Demand.reset_index(), left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['Market', 'Month', 'Product']).set_index(['id_of_Market', 'id_of_Month', 'id_of_Product', 'id_of_Demand'])
    groupbyLevels = ['id_of_Demand']
    groupby_ExecutedSales = join_ExecutedSales.executedSalesVar.groupby(level=groupbyLevels).sum().to_frame()
    join_ExecutedSales_2 = groupby_ExecutedSales.join(list_of_Demand.Value, how='inner')
    for row in join_ExecutedSales_2[join_ExecutedSales_2.Value.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.executedSalesVar <= row.Value, u'Sales are less than the planned demand', row)
    
    # [ST_18] Constraint : cDeliverMoreThanDemand#1_cIterativeRelationalConstraint
    # Deliver at least firm_sales to markets
    # Label: CT_18_Deliver_at_least_firm_sales_to_markets
    join_Delivery = list_of_Delivery.reset_index().merge(list_of_Firm_sales.reset_index(), left_on=['id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['Market', 'Month', 'Product']).set_index(['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product', 'id_of_Firm_sales'])
    groupbyLevels = ['id_of_Firm_sales']
    groupby_Delivery = join_Delivery.deliveryVar.groupby(level=groupbyLevels).sum().to_frame()
    join_Delivery_2 = groupby_Delivery.join(list_of_Firm_sales.Value, how='inner')
    for row in join_Delivery_2[join_Delivery_2.Value.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.deliveryVar >= row.Value, u'Deliver at least firm_sales to markets', row)
    
    # [ST_19] Constraint : cIterativeRelationalConstraint#1_cIterativeRelationalConstraint
    # For each plant_month_capacity, total associated productions is less than or equal to Value
    # Label: CT_19_For_each_plant_month_capacity__total_associated_productions_is_less_than_or_equal_to_Value
    join_Plant_month_capacity = list_of_Plant_month_capacity.reset_index().merge(list_of_Production.reset_index(), left_on=['Plant', 'Month'], right_on=['id_of_Plant', 'id_of_Month']).set_index(['id_of_Plant_month_capacity', 'id_of_Plant', 'id_of_Month', 'id_of_Product'])
    groupbyLevels = ['id_of_Plant_month_capacity']
    groupby_Plant_month_capacity = join_Plant_month_capacity.productionVar.groupby(level=groupbyLevels).sum().to_frame()
    join_Plant_month_capacity_2 = groupby_Plant_month_capacity.join(list_of_Plant_month_capacity.Value, how='inner')
    for row in join_Plant_month_capacity_2[join_Plant_month_capacity_2.Value.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.productionVar <= row.Value, u'For each plant_month_capacity, total associated productions is less than or equal to Value', row)
    
    # [ST_20] Constraint : cLinkDeliveryToProduction#1_cIterativeRelationalConstraint
    # For each production, associated deliveries is less than or equal to production
    # Label: CT_20_For_each_production__associated_deliveries_is_less_than_or_equal_to_production
    join_Production = list_of_Production.reset_index().merge(list_of_Delivery.reset_index(), left_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Month', 'id_of_Product']).set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product', 'id_of_Market'])
    join_Delivery = list_of_Delivery.reset_index().merge(join_Production.reset_index()[['id_of_Plant', 'id_of_Month', 'id_of_Product', 'id_of_Market', 'productionVar', 'deliveryVar']], left_on=['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product'], suffixes=('', '_right'), how='inner').set_index(['id_of_Plant', 'id_of_Market', 'id_of_Month', 'id_of_Product'])
    groupbyLevels = ['id_of_Plant', 'id_of_Month', 'id_of_Product']
    groupby_Delivery = join_Delivery.deliveryVar.groupby(level=groupbyLevels).sum().to_frame()
    join_Delivery_2 = groupby_Delivery.reset_index().merge(list_of_Production.reset_index()[['id_of_Plant', 'id_of_Month', 'id_of_Product', 'productionVar']], left_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], right_on=['id_of_Plant', 'id_of_Month', 'id_of_Product'], how='inner').set_index(['id_of_Plant', 'id_of_Month', 'id_of_Product'])
    for row in join_Delivery_2.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.deliveryVar <= row.productionVar, u'For each production, associated deliveries is less than or equal to production', row)
    
    # [ST_21] Constraint : cGlobalRelationalConstraint#1_cGlobalRelationalConstraint
    # total Productions is less than or equal to 2999000
    # Label: CT_21_total_Productions_is_less_than_or_equal_to_2999000
    agg_Production_productionVar_lhs = mdl.sum(list_of_Production.productionVar)
    helper_add_labeled_cplex_constraint(mdl, agg_Production_productionVar_lhs <= 2999000, u'total Productions is less than or equal to 2999000')
    
    # [ST_22] Constraint : cGlobalRelationalConstraint#2_cGlobalRelationalConstraint
    # total Productions where [ product is 200S ] is less than or equal to 100000
    # Label: CT_22_total_Productions_where___product_is_200S___is_less_than_or_equal_to_100000
    filtered_Production_lhs = list_of_Production.loc[helper_get_level_values(list_of_Production, 'id_of_Product') == u'200S'].copy()
    agg_Production_productionVar_lhs = mdl.sum(filtered_Production_lhs.productionVar)
    helper_add_labeled_cplex_constraint(mdl, agg_Production_productionVar_lhs <= 100000, u'total Productions where [ product is 200S ] is less than or equal to 100000')
    
    # [ST_23] Constraint : cGlobalRelationalConstraint#3_cGlobalRelationalConstraint
    # total Productions where [ product is 200S and where plant is Houston ] is less than or equal to 1000000
    # Label: CT_23_total_Productions_where___product_is_200S_and_where_plant_is_Houston___is_less_than_or_equal_to_1000000
    filtered_Production_lhs = list_of_Production.loc[helper_get_level_values(list_of_Production, 'id_of_Product') == u'200S'].copy()
    filtered_Production_lhs_2 = filtered_Production_lhs.loc[helper_get_level_values(filtered_Production_lhs, 'id_of_Plant') == u'Houston'].copy()
    agg_Production_productionVar_lhs = mdl.sum(filtered_Production_lhs_2.productionVar)
    helper_add_labeled_cplex_constraint(mdl, agg_Production_productionVar_lhs <= 1000000, u'total Productions where [ product is 200S and where plant is Houston ] is less than or equal to 1000000')


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    if mdl.get_solve_status() == JobSolveStatus.UNKNOWN:
        print('UNKNOWN cause: %s' % mdl.get_solve_details().status)
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('Internal constraint', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = list_of_conflicts.append({'constraint': label, 'context': str(context), 'detail': ct},
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_Production_solution = pd.DataFrame(index=list_of_Production.index)
    list_of_Production_solution['productionVar'] = msol.get_values(list_of_Production.productionVar.values)
    list_of_ExecutedSales_solution = pd.DataFrame(index=list_of_ExecutedSales.index)
    list_of_ExecutedSales_solution['executedSalesVar'] = msol.get_values(list_of_ExecutedSales.executedSalesVar.values)
    list_of_CustomerInventory_solution = pd.DataFrame(index=list_of_CustomerInventory.index)
    list_of_CustomerInventory_solution['customerInventoryVar'] = msol.get_values(list_of_CustomerInventory.customerInventoryVar.values)
    list_of_Inventory_solution = pd.DataFrame(index=list_of_Inventory.index)
    list_of_Inventory_solution['inventoryVar'] = msol.get_values(list_of_Inventory.inventoryVar.values)
    list_of_Delivery_solution = pd.DataFrame(index=list_of_Delivery.index)
    list_of_Delivery_solution['deliveryVar'] = msol.get_values(list_of_Delivery.deliveryVar.values)
    plantInventory = pd.DataFrame(index=list_of_Inventory.index)
    
    # Adding extra columns based on Solution Schema
    plantInventory['plant inventory decision'] = list_of_Inventory_solution['inventoryVar']
    join_Inventory = list_of_Inventory.join(list_of_Month.Next, how='inner')
    plantInventory['month Next'] = join_Inventory['Next']
    join_Inventory = list_of_Inventory.join(list_of_Month.Quarter, how='inner')
    plantInventory['month Quarter'] = join_Inventory['Quarter']
    join_Inventory = list_of_Inventory.join(list_of_Month.Index, how='inner')
    plantInventory['month Index'] = join_Inventory['Index']
    join_Inventory = list_of_Inventory.join(list_of_Product.Type, how='inner')
    plantInventory['product Type'] = join_Inventory['Type']
    join_Inventory = list_of_Inventory.join(list_of_Product.Price_Level, how='inner')
    plantInventory['product Price Level'] = join_Inventory['Price_Level']
    join_Inventory = list_of_Inventory.join(list_of_Product.Maturity, how='inner')
    plantInventory['product Maturity'] = join_Inventory['Maturity']
    plantInventory = plantInventory.round({'plant inventory decision': 2})
    
    delivery = pd.DataFrame(index=list_of_Delivery.index)
    delivery['delivery decision'] = list_of_Delivery_solution['deliveryVar']
    join_Delivery = list_of_Delivery.join(list_of_Market.Region, how='inner')
    delivery['market Region'] = join_Delivery['Region']
    join_Delivery = list_of_Delivery.join(list_of_Month.Next, how='inner')
    delivery['month Next'] = join_Delivery['Next']
    join_Delivery = list_of_Delivery.join(list_of_Month.Quarter, how='inner')
    delivery['month Quarter'] = join_Delivery['Quarter']
    join_Delivery = list_of_Delivery.join(list_of_Month.Index, how='inner')
    delivery['month Index'] = join_Delivery['Index']
    join_Delivery = list_of_Delivery.join(list_of_Product.Type, how='inner')
    delivery['product Type'] = join_Delivery['Type']
    join_Delivery = list_of_Delivery.join(list_of_Product.Price_Level, how='inner')
    delivery['product Price Level'] = join_Delivery['Price_Level']
    join_Delivery = list_of_Delivery.join(list_of_Product.Maturity, how='inner')
    delivery['product Maturity'] = join_Delivery['Maturity']
    delivery = delivery.round({'delivery decision': 2})
    
    production = pd.DataFrame(index=list_of_Production.index)
    production['production decision'] = list_of_Production_solution['productionVar']
    join_Production = list_of_Production.join(list_of_Month.Next, how='inner')
    production['month Next'] = join_Production['Next']
    join_Production = list_of_Production.join(list_of_Month.Quarter, how='inner')
    production['month Quarter'] = join_Production['Quarter']
    join_Production = list_of_Production.join(list_of_Month.Index, how='inner')
    production['month Index'] = join_Production['Index']
    join_Production = list_of_Production.join(list_of_Product.Type, how='inner')
    production['product Type'] = join_Production['Type']
    join_Production = list_of_Production.join(list_of_Product.Price_Level, how='inner')
    production['product Price Level'] = join_Production['Price_Level']
    join_Production = list_of_Production.join(list_of_Product.Maturity, how='inner')
    production['product Maturity'] = join_Production['Maturity']
    production = production.round({'production decision': 2})
    
    marketInventory = pd.DataFrame(index=list_of_CustomerInventory.index)
    marketInventory['market inventory decision'] = list_of_CustomerInventory_solution['customerInventoryVar']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Market.Region, how='inner')
    marketInventory['market Region'] = join_CustomerInventory['Region']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Month.Next, how='inner')
    marketInventory['month Next'] = join_CustomerInventory['Next']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Month.Quarter, how='inner')
    marketInventory['month Quarter'] = join_CustomerInventory['Quarter']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Month.Index, how='inner')
    marketInventory['month Index'] = join_CustomerInventory['Index']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Product.Type, how='inner')
    marketInventory['product Type'] = join_CustomerInventory['Type']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Product.Price_Level, how='inner')
    marketInventory['product Price Level'] = join_CustomerInventory['Price_Level']
    join_CustomerInventory = list_of_CustomerInventory.join(list_of_Product.Maturity, how='inner')
    marketInventory['product Maturity'] = join_CustomerInventory['Maturity']
    marketInventory = marketInventory.round({'market inventory decision': 2})
    
    executedSales = pd.DataFrame(index=list_of_ExecutedSales.index)
    executedSales['executed sales decision'] = list_of_ExecutedSales_solution['executedSalesVar']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Market.Region, how='inner')
    executedSales['market Region'] = join_ExecutedSales['Region']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Month.Next, how='inner')
    executedSales['month Next'] = join_ExecutedSales['Next']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Month.Quarter, how='inner')
    executedSales['month Quarter'] = join_ExecutedSales['Quarter']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Month.Index, how='inner')
    executedSales['month Index'] = join_ExecutedSales['Index']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Product.Type, how='inner')
    executedSales['product Type'] = join_ExecutedSales['Type']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Product.Price_Level, how='inner')
    executedSales['product Price Level'] = join_ExecutedSales['Price_Level']
    join_ExecutedSales = list_of_ExecutedSales.join(list_of_Product.Maturity, how='inner')
    executedSales['product Maturity'] = join_ExecutedSales['Maturity']
    executedSales = executedSales.round({'executed sales decision': 2})
    

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['delivery'] = delivery[['delivery decision', 'market Region', 'month Next', 'month Quarter', 'month Index', 'product Type', 'product Price Level', 'product Maturity']].reset_index().rename(columns= {'id_of_Market': 'market', 'id_of_Product': 'product', 'id_of_Month': 'month', 'id_of_Plant': 'plant'})
        outputs['marketInventory'] = marketInventory[['market inventory decision', 'market Region', 'month Next', 'month Quarter', 'month Index', 'product Type', 'product Price Level', 'product Maturity']].reset_index().rename(columns= {'id_of_Market': 'market', 'id_of_Product': 'product', 'id_of_Month': 'month'})
        outputs['production'] = production[['production decision', 'month Next', 'month Quarter', 'month Index', 'product Type', 'product Price Level', 'product Maturity']].reset_index().rename(columns= {'id_of_Product': 'product', 'id_of_Month': 'month', 'id_of_Plant': 'plant'})
        outputs['plantInventory'] = plantInventory[['plant inventory decision', 'month Next', 'month Quarter', 'month Index', 'product Type', 'product Price Level', 'product Maturity']].reset_index().rename(columns= {'id_of_Product': 'product', 'id_of_Month': 'month', 'id_of_Plant': 'plant'})
        outputs['executedSales'] = executedSales[['executed sales decision', 'market Region', 'month Next', 'month Quarter', 'month Index', 'product Type', 'product Price Level', 'product Maturity']].reset_index().rename(columns= {'id_of_Market': 'market', 'id_of_Product': 'product', 'id_of_Month': 'month'})
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Import custom code definition if module exists
try:
    from custom_code import CustomCode
    custom_code = CustomCode(globals())
except ImportError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()


from docplex.mp.progress import ProgressListener
from docplex.util.environment import add_abort_callback, remove_abort_callback
from functools import partial


class SolutionListener(ProgressListener):
    def __init__(self):
        super(SolutionListener, self).__init__()
        self._cpx_incumbent_sol = None

    def requires_solution(self):
        return True

    def notify_solution(self, cpx_incumbent_sol):
        self._cpx_incumbent_sol = cpx_incumbent_sol


def save_and_write_last_solution_callback(sol_listener, outputs):
    if sol_listener._cpx_incumbent_sol:
        export_solution(sol_listener._cpx_incumbent_sol)
    write_all_outputs(outputs)


solution_listener = SolutionListener()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

#
model.add_progress_listener(solution_listener)
env = get_environment()
# Remove default abort callbacks
for cb in env.abort_callbacks:
    remove_abort_callback(cb)
# Add new abort callback to store latest found solution, if any
add_abort_callback(partial(save_and_write_last_solution_callback, solution_listener, outputs))

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
