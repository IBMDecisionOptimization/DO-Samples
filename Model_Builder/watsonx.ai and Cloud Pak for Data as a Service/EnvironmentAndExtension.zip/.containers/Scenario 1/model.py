# Use Python package file to create "diet_nutrient" table
from diet_data.diet_data import generate_nutrients_data

diet_nutrient = generate_nutrients_data()


# Use YAML code to get prettytable via pip
from prettytable import from_csv
from io import StringIO

diet_prettytable = from_csv(StringIO(diet_nutrient.to_csv(index=False)))

print(diet_prettytable)