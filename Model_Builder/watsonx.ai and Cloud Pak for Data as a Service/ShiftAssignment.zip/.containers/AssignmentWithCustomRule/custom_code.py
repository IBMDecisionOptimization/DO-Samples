##--- Begin custom rule class CustomCode

class CustomCode:
    def __init__(self, ctxt):
        self.ctxt = ctxt
        self.update_globals(ctxt)

    def update_globals(self, ctxt):
        # Add all global variables from calling environment to current name space for easy access
        globals().update(ctxt)
        
    ##--- Functions implementing custom rules
    
    ##--- Custom rule function limitConsecutiveAssignments (id: 9acd415b-1c82-40f5-9766-e0390f07eeac)

    # -- # Data Structure for parameter: employees   --------------------
    # -- # DataFrame: Employee
    # -- # PrimaryKey  : id_of_Employee
    # -- #             : pay rate
    # -- #             : qualification
    # -- #             : seniority
    # -- #
    # -- # Data Structure for parameter: on_call_duties   --------------------
    # -- # DataFrame: OnCallDuty
    # -- # PrimaryKey  : id_of_Day
    # -- # PrimaryKey  : id_of_Employee
    # -- # DecisionVar : onCallDutyVar
    # -- #
    def limitConsecutiveAssignments(self, mdl, employees, on_call_duties, limit):
        global helper_add_labeled_cplex_constraint, helper_get_index_names_for_type, helper_get_column_name_for_property
        print('Adding constraints for the custom rule')
        for employee, duties in employees.associated(on_call_duties):
            duties_day_idx = duties.join(Day)  # Retrieve Day index from Day label
            for d in Day['index']:
                end = d + limit + 1  # One must enforce that there are no occurence of (limit + 1) working consecutive days
                duties_in_win = duties_day_idx[((duties_day_idx['index'] >= d) & (duties_day_idx['index'] <= end)) | (duties_day_idx['index'] <= end - 7)]
                mdl.add_constraint(mdl.sum(duties_in_win.onCallDutyVar) <= limit)
 
    ##--- Other customization functions (can be optionally refined)

    def preprocess(self):
        """
        Code to pre-process input data or importing more input data
        """
        print('CUSTOM RULES preprocess %%')
        pass

    def update_goals_list(self, kpis_expression_list):
        """
        'kpis_expression_list' is a list of tuples (kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name)
        defining the objective. The objective is computed according to the following expression:
        sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list])
        This list may be updated in this method in order to customize the definition of the objective.
        """
        pass

    def update_model(self, mdl):
        """
        Code to add new decision variables and/or more constraints
        """
        print('CUSTOM RULES update model')
        pass

    def update_solver_params(self, params):
        """
        Code to configure solver parameters
        """
        # Example: Update default value for solver time limit to 10 seconds
        # params.timelimit = 10

    def post_process_solution(self, msol, outputs):
        """
        Code to:
           - post-process intermediate solution: add calculated columns to solution dataframes,...
           - add custom columns to existing exported dataframes
        """
        print('CUSTOM RULES postprocess')
        pass

##--- End custom rule class CustomCode



