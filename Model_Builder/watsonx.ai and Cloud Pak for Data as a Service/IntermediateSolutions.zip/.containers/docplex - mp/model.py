'''
Created on Jan 26, 2015

@author: vberaudi
taken from http://ccgi.gladman.plus.com/wp/?page_id=1316
'''
from docplex.mp.model import Model
from docplex.mp.progress import SolutionListener

import pandas as pd

#-----------------------------------------------------------------------------
# Implement a SolutionListener to save and publish solution tables.
#-----------------------------------------------------------------------------
def build_solution(sol, index):
    solution = [(index , dv.name, dvv) for dv, dvv in sol.iter_var_values()]
    solution = pd.DataFrame(solution, columns=["iteration", "name", "value"])
    outputs['my_solution'] = solution


class SolutionKeeper(SolutionListener):
    """ A specialized implementation of :class:`SolutionListener`, which keeps track
    of the latest intermediate solution found.
    """
    def __init__(self):
        SolutionListener.__init__(self)
        self.index = -1

    def notify_solution(self, sol):
        self.index +=1
        build_solution(sol, self.index)
        #  `write_all_outputs()` will publish tables from outputs dictionnary as solution tables
        write_all_outputs(outputs)


# This model solves this geometric puzzle:
# Starting with a pattern of circles placed in rows with each row containing one less circle than the row below it, until there is just one circle at the top.
# You must decide which circles to color in so that the maximum number of circles are colored in.
# However, there is the constraint that no 3 colored circles form a triangle. 
# Hence the center of each circle is considered as a vertex for a potential triangle (that you want to avoid).

# The circles are numbered as follows:
#
# 1               (1, 1)
# 2   3         (2, 1)   (2, 2)
# 4   5   6   (3, 1)   (3, 2)   (3, 3)
# ....
def build_hearts(r, **kwargs):
    # initialize the model
    mdl = Model('love_hearts_%d' % r, **kwargs)

    # the dictionary of decision variables, one variable
    # for each circle with i in (1 .. r) as the row and
    # j in (1 .. i) as the position within the row    
    idx = [(i, j) for i in range(1, r + 1) for j in range(1, i + 1)]
    a = mdl.binary_var_dict(idx, name=lambda idx_tuple: "a_%d_%d" % (idx_tuple[0], idx_tuple[1]))
    mdl.a = a
    mdl.r = r
    mdl.idx = idx

    # the constraints - enumerate all equilateral triangles
    # and prevent any such triangles from being chosen by keeping
    # the number of chosen circles with adjacent vertices below 3

    # for each row except the last
    for i in range(1, r):
        # for each position in this row
        for j in range(1, i + 1):
            # for each triangle of side length (k) with its upper vertex at
            # (i, j) and its sides parallel to those of the overall shape
            for k in range(1, r - i + 1):
                # the sets of 3 points at the same distances clockwise along the
                # sides of these triangles form k equilateral triangles
                for m in range(k):
                    u, v, w = (i + m, j), (i + k, j + m), (i + k - m, j + k - m)
                    mdl.add_constraint(a[u] + a[v] + a[w] <= 2)

    mdl.maximize(mdl.sum(a))
    mdl.add_kpi(mdl.sum(a), "my_kpi")
    return mdl


def solve_hearts(r):

    mdl = build_hearts(r)

    # To obtain tables for intermediate solutions, you must add a SolutionListener
    # so that you can then create solution tables and publish them.
    mdl.add_progress_listener(SolutionKeeper())

    mdl.print_information()
    sol = mdl.solve()
    if not sol:
        print("*** solve fails")
        return -1

    build_solution(sol, "final")

    val = mdl.objective_value
    mdl.report()
    mdl.end()
    return val

SIZE = 13 # quite fast until 12, 13 takes a few minutes, 14 is open
solve_hearts(SIZE)
