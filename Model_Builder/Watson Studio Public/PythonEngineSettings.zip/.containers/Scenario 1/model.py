from docplex.mp.model import Model


# This model solves this geometric puzzle:  
# Start with a pattern of circles placed in rows piled one on top of the other with decreasing
# numbers in each row to form a triangle. With N circles at the bottom, then N-1 circles in
# the adjacent row, then N-2 in the next row etc ... until there is just 1 circle in the top
# row, you must decide which circles to color in, so that the maximum number of circles are
# colored in. There is however the constraint that no 3 selected circles form a triangle.
# Hence the center of any circle is considered as a vertex for a potential triangle.

# the circles are numbered as follows:
#
# 1               (1, 1)
# 2   3         (2, 1)   (2, 2)
# 4   5   6   (3, 1)   (3, 2)   (3, 3)
# ....
def build_hearts(r, **kwargs):
    # initialize the model
    mdl = Model('love_hearts_%d' % r, **kwargs)

    # the dictionary of decision variables, one variable
    # for each circle with i in (1 .. r) as the row and
    # j in (1 .. i) as the position within the row    
    idx = [(i, j) for i in range(1, r + 1) for j in range(1, i + 1)]
    a = mdl.binary_var_dict(idx, name=lambda idx_tuple: "a_%d_%d" % (idx_tuple[0], idx_tuple[1]))

    # the constraints - enumerate all equilateral triangles
    # and prevent any such triangles being formed by keeping
    # the number of included circles at its vertexes below 3

    # for each row except the last
    for i in range(1, r):
        # for each position in this row
        for j in range(1, i + 1):
            # for each triangle of side length (k) with its upper vertex at
            # (i, j) and its sides parallel to those of the overall shape
            for k in range(1, r - i + 1):
                # the sets of 3 points at the same distances clockwise along the
                # sides of these triangles form k equilateral triangles
                for m in range(k):
                    u, v, w = (i + m, j), (i + k, j + m), (i + k - m, j + k - m)
                    mdl.add_constraint(a[u] + a[v] + a[w] <= 2)

    mdl.maximize(mdl.sum(a))
    return mdl


if __name__ == '__main__':
    import sys
    SIZE = 8 # The solve time depends on the model size (the number of circles). For 8-12 solve time is quite fast, 13 takes a few minutes, 14+ solve time might be a lot longer
    print("* running love hearts puzzle with size=%d" % SIZE)
    val1, val2, val3, val4 = 0.0,0.0,0.0,0.0


    # Load the intsollim2.ops settings file
    from docplex.mp.model_reader import ModelReader
    prm = ModelReader.read_ops_file(filename="intsollim2.ops")
    
    print("\nNon default CPLEX parameters are:")
    for p in prm.generate_nondefault_params():
        print("{0}".format(p))
    print("End of non default parameters\n\n")


    with build_hearts(r=SIZE) as mdl:
        mdl.solve()
        val1 = mdl.objective_value
        print("Solve with default: " + str(val1))
        
    ## 1st way to use the parameters with CPLEX model: pass prm in solve method
    with build_hearts(r=SIZE) as mdl:
        mdl.solve(cplex_parameters = prm)
        val2 = mdl.objective_value
        print("Solve with params through solve method and .ops file: "+str(val2))

    ## 2nd way to use the parameters with CPLEX model: pass prm as Model constructor param
    with build_hearts(r=SIZE, parameters = prm) as mdl:
        mdl.solve()
        val3 = mdl.objective_value
        print("Solve with params through Model constructor and .ops file: "+str(val3))
        
    with build_hearts(r=SIZE) as mdl:
        mdl.parameters.mip.limits.solutions  =2
        mdl.solve()
        val4 = mdl.objective_value
        print("Solve with params through standard python code: "+str(val4))
    
    if val1 * val2 * val3 * val4 == 0.0:
        raise Exception("Solve failed")
    if val2 != val4 or val3 != val4:
        raise Exception("Solve with params failed")
    if val1 == val2:
        raise Exception("Solve with parameters failed")
    print("all checks are good")