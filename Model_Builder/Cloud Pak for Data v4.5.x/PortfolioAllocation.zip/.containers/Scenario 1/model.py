from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys



# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


from pandas.api.types import is_string_dtype


def helper_check_data_type(df, column, df_label, check_type):
    if not column in df.columns:
        print('Column "%s" does not exist in table "%s"' % (column, df_label))
        return False
    non_nan_values = df[column][~df[column].isnull()]
    if check_type == 'INTEGER':
        k = non_nan_values.dtype.kind
        if k != 'i':
            if k == 'f':
                non_integer_values = non_nan_values.values[np.where([not x.is_integer() for x in non_nan_values])]
                if len(non_integer_values) > 0:
                    print('Column "%s" of table "%s" contains non-integer value(s) which violates expected type: %s' % (column, df_label, non_integer_values))
                    return False
            else:
                print('Column "%s" of table "%s" is non-numeric which violates expected type: %s' % (column, df_label, non_nan_values.values))
                return False
    elif check_type == 'FLOAT' or check_type == 'NUMBER':
        non_float_values = non_nan_values.values[np.where([not isinstance(x, (int, float)) for x in non_nan_values])]
        k = non_nan_values.dtype.kind
        if not k in ['i', 'f']:
            print('Column "%s" of table "%s" contains non-float value(s) which violates expected type: %s' % (column, df_label, non_float_values))
            return False
    elif check_type == 'BOOLEAN':
        non_bool_values = non_nan_values.values[np.where([not isinstance(x, bool) and not x in [0, 1] for x in non_nan_values])]
        if len(non_bool_values) > 0:
            print('Column "%s" of table "%s" contains non-boolean value(s) which violates expected type: %s' % (column, df_label, non_bool_values))
            return False
    elif check_type == 'Date' or check_type == 'DateTime':
        try:
            pd.to_datetime(non_nan_values)
        except ValueError as e:
            print('Column "%s" of table "%s" cannot be converted to a DateTime : %s' % (column, df_label, str(e)))
            return False
    elif check_type == 'Time':
        try:
            pd.to_timedelta(non_nan_values)
        except ValueError as e:
            try:
                # Try appending ':00' in case seconds are not represented in time
                pd.to_timedelta(non_nan_values + ':00')
            except ValueError as e:
                print('Column "%s" of table "%s" cannot be converted to a Time : %s' % (column, df_label, str(e)))
                return False
    elif check_type == 'STRING':
        if not is_string_dtype(non_nan_values):
            print('Column "%s" of table "%s" is not of type "String"' % (column, df_label))
            return False
    else:
        raise Exception('Invalid check_type: %s' % check_type)
    return True


def helper_check_foreignKey_values(source_df, source_column, source_df_label, target_df, target_column, target_df_label):
    non_nan_values = source_df[source_column][~source_df[source_column].isnull()]
    invalid_FK_values = non_nan_values[~non_nan_values.isin(target_df[target_column])].values
    if len(invalid_FK_values) > 0:
        print('FK Column "%s" of table "%s" contains values that do not exist in PK column "%s" of target table "%s": %s' % (source_column, source_df_label, target_column, target_df_label, invalid_FK_values))
        return False
    return True


def helper_check_unique_primaryKey_values(df, key_cols, df_label):
    df_grp = df.groupby(key_cols).size()
    invalid_pk_values = df_grp[df_grp > 1].reset_index()[key_cols].values
    if len(invalid_pk_values) > 0:
        print('Non-unique values for PK of table "%s": %s' % (df_label, invalid_pk_values))
        return False
    return True


# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'cCovarianceMatrixConcept': ['id_of_Covariance'],
    'cItem': ['id_of_Investment'],
    'country': ['id_of_Country'],
    'covariance': ['id_of_Covariance'],
    'industry': ['id_of_Industry'],
    'investment': ['id_of_Investment'],
    'param': ['id_of_Param'],
    'recommendation': ['id_of_Recommendation']}
helper_property_id_to_column_names_map = {
    'cCovarianceMatrixConcept.item1': 'investment_1',
    'cCovarianceMatrixConcept.item2': 'investment_2',
    'cCovarianceMatrixConcept.value': 'value',
    'covariance.investment_1': 'investment_1',
    'covariance.investment_2': 'investment_2',
    'covariance.value': 'value',
    'investment.country': 'country',
    'investment.expected return': 'expected_return',
    'investment.expected return amount': 'expected_return_amount',
    'investment.index': 'index_',
    'investment.industry': 'industry',
    'investment.recommendation': 'recommendation',
    'investment.stock price': 'stock_price',
    'param.budget': 'budget',
    'param.rho': 'rho'}


# Data model definition for each table
# Data collection: list_of_Country ['id']
# Data collection: list_of_Covariance ['investment_1', 'investment_2', 'value', '__line']
# Data collection: list_of_Industry ['id']
# Data collection: list_of_Investment ['stock_price', 'recommendation', 'industry', 'index_', 'expected_return_amount', 'expected_return', 'country', 'id']
# Data collection: list_of_Param ['wealth_prct', 'rho', 'budget']
# Data collection: list_of_Recommendation ['id']

# Create a pandas Dataframe for each data table
list_of_Covariance = inputs[u'covariance']
list_of_Covariance = list_of_Covariance[[u'investment_1', u'investment_2', u'value']].copy()
list_of_Covariance.rename(columns={u'investment_1': 'investment_1', u'investment_2': 'investment_2', u'value': 'value'}, inplace=True)
list_of_Investment = inputs[u'investment']
list_of_Investment = list_of_Investment[[u'stock price', u'recommendation', u'industry', u'index', u'expected return amount', u'expected return', u'country', u'id']].copy()
list_of_Investment.rename(columns={u'stock price': 'stock_price', u'recommendation': 'recommendation', u'industry': 'industry', u'index': 'index_', u'expected return amount': 'expected_return_amount', u'expected return': 'expected_return', u'country': 'country', u'id': 'id'}, inplace=True)
list_of_Param = inputs[u'param']
list_of_Param = list_of_Param[[u'wealth prct', u'rho', u'budget']].copy()
list_of_Param.rename(columns={u'wealth prct': 'wealth_prct', u'rho': 'rho', u'budget': 'budget'}, inplace=True)
# --- Handling table for implicit concept
list_of_Country = pd.DataFrame(inputs[u'investment']['country'].unique(), columns=['id']).dropna()
# --- Handling table for implicit concept
list_of_Industry = pd.DataFrame(inputs[u'investment']['industry'].unique(), columns=['id']).dropna()
# --- Handling table for implicit concept
list_of_Recommendation = pd.DataFrame(inputs[u'investment']['recommendation'].unique(), columns=['id']).dropna()

# Perform input data checking against schema configured in Modelling Assistant along with unicity of PK values
data_check_result = True
# --- Handling data checking for implicit concept: country
# --- Handling data checking for table: covariance
data_check_result &= helper_check_foreignKey_values(list_of_Covariance, 'investment_1', 'covariance', list_of_Investment, 'id', 'investment')
data_check_result &= helper_check_foreignKey_values(list_of_Covariance, 'investment_2', 'covariance', list_of_Investment, 'id', 'investment')
data_check_result &= helper_check_data_type(list_of_Covariance, 'value', 'covariance', 'NUMBER')
# --- Handling data checking for implicit concept: industry
# --- Handling data checking for table: investment
data_check_result &= helper_check_data_type(list_of_Investment, 'stock_price', 'investment', 'NUMBER')
data_check_result &= helper_check_foreignKey_values(list_of_Investment, 'recommendation', 'investment', list_of_Recommendation, 'id', 'recommendation')
data_check_result &= helper_check_foreignKey_values(list_of_Investment, 'industry', 'investment', list_of_Industry, 'id', 'industry')
data_check_result &= helper_check_data_type(list_of_Investment, 'index_', 'investment', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Investment, 'expected_return_amount', 'investment', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Investment, 'expected_return', 'investment', 'NUMBER')
data_check_result &= helper_check_foreignKey_values(list_of_Investment, 'country', 'investment', list_of_Country, 'id', 'country')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Investment, ['id'], 'investment')
# --- Handling data checking for table: param
data_check_result &= helper_check_data_type(list_of_Param, 'wealth_prct', 'param', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Param, 'rho', 'param', 'NUMBER')
data_check_result &= helper_check_data_type(list_of_Param, 'budget', 'param', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Param, ['wealth_prct'], 'param')
# --- Handling data checking for implicit concept: recommendation
if not data_check_result:
    # Stop execution here
    raise Exception('Data checking detected errors')

# Force column type for non-numeric columns
list_of_Country = list_of_Country.astype({'id': object})
list_of_Covariance = list_of_Covariance.astype({'investment_1': object, 'investment_2': object})
list_of_Industry = list_of_Industry.astype({'id': object})
list_of_Investment = list_of_Investment.astype({'recommendation': object, 'industry': object, 'country': object, 'id': object})
list_of_Recommendation = list_of_Recommendation.astype({'id': object})

# Set index when a primary key is defined
list_of_Country.set_index('id', inplace=True)
list_of_Country.sort_index(inplace=True)
list_of_Country.index.name = 'id_of_Country'
list_of_Covariance.index.name = 'id_of_Covariance'
list_of_Industry.set_index('id', inplace=True)
list_of_Industry.sort_index(inplace=True)
list_of_Industry.index.name = 'id_of_Industry'
list_of_Investment.set_index('id', inplace=True)
list_of_Investment.sort_index(inplace=True)
list_of_Investment.index.name = 'id_of_Investment'
list_of_Param.set_index('wealth_prct', inplace=True)
list_of_Param.sort_index(inplace=True)
list_of_Param.index.name = 'id_of_Param'
list_of_Recommendation.set_index('id', inplace=True)
list_of_Recommendation.sort_index(inplace=True)
list_of_Recommendation.index.name = 'id_of_Recommendation'







def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_Investment['allocationVar'] = mdl.continuous_var_list(len(list_of_Investment))
    list_of_Investment['selectionVar'] = mdl.binary_var_list(len(list_of_Investment))
    list_of_Investment['integerSubAllocationVar'] = mdl.integer_var_list(len(list_of_Investment))



    # Definition of model
    # Objective cMaximizeGoalSelect#1-
    # Combine weighted criteria: 
    # 	cMaximizeGoalSelect cMaximizeGoalSelect 1.2{
    # 	numericExpr = cAllocation__investment__ / investment / expected return,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null} with weight 5.0
    # 	cMinimizeCovariance cMinimizeCovariance 1.2{
    # 	allocation = cAllocation__investment__,
    # 	covarianceMatrix = covariance,
    # 	scaleFactorExpr = param / rho / 2,
    # 	(static) goalFilter = null,
    # 	(static) multiplier = 1,
    # 	(static) numericExpr = total 1 * total covariance / value * decisionPath(covariance / investment_1 / inverse(cAllocation.investment)) * decisionPath(covariance / investment_2 / inverse(cAllocation.investment)) over covariance} with weight 5.0
    list_of_Investment['conditioned_expected_return'] = list_of_Investment.allocationVar * list_of_Investment.expected_return
    agg_Investment_conditioned_expected_return_SG1 = mdl.sum(list_of_Investment.conditioned_expected_return)
    join_Covariance_SG2 = list_of_Covariance.reset_index().join(list_of_Investment.allocationVar, on=['investment_1'], how='inner').set_index(['id_of_Covariance'])
    join_Covariance_SG2_2 = list_of_Covariance.reset_index().join(list_of_Investment.allocationVar, on=['investment_2'], how='inner').set_index(['id_of_Covariance'])
    bin_op_Covariance_SG2 = pd.Series(join_Covariance_SG2.allocationVar * join_Covariance_SG2_2.allocationVar, name='result').to_frame()
    bin_op_Covariance_SG2_2 = pd.Series(list_of_Covariance.value[list_of_Covariance.value.notnull()] * bin_op_Covariance_SG2.result[bin_op_Covariance_SG2.result.notnull()], name='result').to_frame()
    bin_op_1_SG2 = pd.Series(1.0 * bin_op_Covariance_SG2_2.result[bin_op_Covariance_SG2_2.result.notnull()], name='result').to_frame()
    agg_1_result_SG2 = mdl.sum(bin_op_1_SG2.result)
    bin_op_Param_rho_SG2 = list_of_Param.rho.iloc[0] / 2
    
    kpis_expression_list = [
        (-1, 16.0, agg_Investment_conditioned_expected_return_SG1, 1, 0, u'total expected return of investments over all allocations'),
        (1, 16.0, agg_1_result_SG2, bin_op_Param_rho_SG2, 0, u'dependencies between investment allocations based on covariances')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_expr, publish_name=kpi_name)
    
    mdl.minimize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cLinkSelectionToAllocationConstraint#1_cIterativeRelationalConstraint
    # (Implicit rule) Synchronize selection with investment allocations
    # Label: CT_1__Implicit_rule__Synchronize_selection_with_investment_allocations
    join_Investment = list_of_Investment.reset_index().merge(list_of_Investment.reset_index(), left_on=['id_of_Investment'], right_on=['id_of_Investment'], suffixes=('', '_right')).set_index(['id_of_Investment'])
    groupbyLevels = ['id_of_Investment']
    groupby_Investment = join_Investment.allocationVar.groupby(level=groupbyLevels[0]).sum().to_frame(name='allocationVar')
    list_of_Investment_maxValueAllocation = pd.Series([1000] * len(list_of_Investment)).to_frame('maxValueAllocation').set_index(list_of_Investment.index)
    join_Investment_2 = list_of_Investment.join(list_of_Investment_maxValueAllocation.maxValueAllocation, how='inner')
    join_Investment_2['conditioned_maxValueAllocation'] = join_Investment_2.selectionVar * join_Investment_2.maxValueAllocation
    join_Investment_3 = groupby_Investment.join(join_Investment_2.conditioned_maxValueAllocation, how='inner')
    for row in join_Investment_3.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar <= row.conditioned_maxValueAllocation, u'(Implicit rule) Synchronize selection with investment allocations', row)
    
    # [ST_2] Constraint : cLinkSelectionToAllocationConstraint#1_cIterativeRelationalConstraint
    # (Implicit rule) Synchronize selection with investment allocations
    # Label: CT_2__Implicit_rule__Synchronize_selection_with_investment_allocations
    join_Investment = list_of_Investment.reset_index().merge(list_of_Investment.reset_index(), left_on=['id_of_Investment'], right_on=['id_of_Investment'], suffixes=('', '_right')).set_index(['id_of_Investment'])
    groupbyLevels = ['id_of_Investment']
    groupby_Investment = join_Investment.allocationVar.groupby(level=groupbyLevels[0]).sum().to_frame(name='allocationVar')
    list_of_Investment_minValueAllocationForAssignment = pd.Series([10] * len(list_of_Investment)).to_frame('minValueAllocationForAssignment').set_index(list_of_Investment.index)
    join_Investment_2 = list_of_Investment.join(list_of_Investment_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    join_Investment_2['conditioned_minValueAllocationForAssignment'] = join_Investment_2.selectionVar * join_Investment_2.minValueAllocationForAssignment
    join_Investment_3 = groupby_Investment.join(join_Investment_2.conditioned_minValueAllocationForAssignment, how='inner')
    for row in join_Investment_3.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar >= row.conditioned_minValueAllocationForAssignment, u'(Implicit rule) Synchronize selection with investment allocations', row)
    
    # [ST_3] Constraint : cGlobalRelationalConstraint#1_cGlobalRelationalConstraint
    # number of investment selections is less than or equal to 6
    # Label: CT_3_number_of_investment_selections_is_less_than_or_equal_to_6
    agg_Investment_selectionVar_lhs = mdl.sum(list_of_Investment.selectionVar)
    helper_add_labeled_cplex_constraint(mdl, agg_Investment_selectionVar_lhs <= 6, u'number of investment selections is less than or equal to 6')
    
    # [ST_4] Constraint : cAllocationIsIntegerNumberConstraint#1_cIterativeRelationalConstraint
    # All investment allocations must be an integer multiple of stock price
    # Label: CT_4_All_investment_allocations_must_be_an_integer_multiple_of_stock_price
    bin_op_Investment = pd.Series(list_of_Investment.integerSubAllocationVar * list_of_Investment.stock_price[list_of_Investment.stock_price.notnull()], name='result').to_frame()
    join_Investment = list_of_Investment.join(bin_op_Investment.result, how='inner')
    for row in join_Investment.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar == row.result, u'All investment allocations must be an integer multiple of stock price', row)
    
    # [ST_5] Constraint : cGlobalRelationalConstraint#2_cGlobalRelationalConstraint
    # total allocation over all investments is less than or equal to budget of param
    # Label: CT_5_total_allocation_over_all_investments_is_less_than_or_equal_to_budget_of_param
    agg_Investment_allocationVar_lhs = mdl.sum(list_of_Investment.allocationVar)
    helper_add_labeled_cplex_constraint(mdl, agg_Investment_allocationVar_lhs <= list_of_Param.budget.iloc[0], u'total allocation over all investments is less than or equal to budget of param')
    
    # [ST_6] Constraint : cNoAssignmentForItem#1_cIterativeRelationalConstraint
    # No selection of investments where recommendation of investment is Strong Sell
    # Label: CT_6_No_selection_of_investments_where_recommendation_of_investment_is_Strong_Sell
    filtered_Investment = list_of_Investment[list_of_Investment.recommendation == u'Strong Sell'].copy()
    for row in filtered_Investment.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.selectionVar <= 0, u'No selection of investments where recommendation of investment is Strong Sell', row)
    
    # [ST_7] Constraint : cGlobalRelationalConstraint#3_cGlobalRelationalConstraint
    # total allocation of investments (such that investments country is FR) is less than or equal to 150
    # Label: CT_7_total_allocation_of_investments__such_that_investments_country_is_FR__is_less_than_or_equal_to_150
    filtered_Country_lhs = list_of_Country.loc[[u'FR']]
    join_Country_lhs = filtered_Country_lhs[[]].reset_index().merge(list_of_Investment.reset_index(), left_on=['id_of_Country'], right_on=['country']).set_index(['id_of_Country', 'id_of_Investment'])
    agg_Country_allocationVar_lhs = mdl.sum(join_Country_lhs.allocationVar)
    helper_add_labeled_cplex_constraint(mdl, agg_Country_allocationVar_lhs <= 150, u'total allocation of investments (such that investments country is FR) is less than or equal to 150')
    
    # [ST_8] Constraint : cIterativeRelationalConstraint#1_cIterativeRelationalConstraint
    # For each country, number of selections of investments (such that investments country is country) is less than or equal to 3
    # Label: CT_8_For_each_country__number_of_selections_of_investments__such_that_investments_country_is_country__is_less_than_or_equal_to_3
    join_Country = list_of_Country[[]].reset_index().merge(list_of_Investment.reset_index(), left_on=['id_of_Country'], right_on=['country']).set_index(['id_of_Country', 'id_of_Investment'])
    groupbyLevels = ['id_of_Country']
    groupby_Country = join_Country.selectionVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_Country.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.selectionVar <= 3, u'For each country, number of selections of investments (such that investments country is country) is less than or equal to 3', row)
    
    # [ST_9] Constraint : cIterativeRelationalConstraint#2_cIterativeRelationalConstraint
    # For each industry, number of selections of investments (such that investments industry is industry) is less than or equal to 2
    # Label: CT_9_For_each_industry__number_of_selections_of_investments__such_that_investments_industry_is_industry__is_less_than_or_equal_to_2
    join_Industry = list_of_Industry[[]].reset_index().merge(list_of_Investment.reset_index(), left_on=['id_of_Industry'], right_on=['industry']).set_index(['id_of_Industry', 'id_of_Investment'])
    groupbyLevels = ['id_of_Industry']
    groupby_Industry = join_Industry.selectionVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_Industry.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.selectionVar <= 2, u'For each industry, number of selections of investments (such that investments industry is industry) is less than or equal to 2', row)
    
    # [ST_10] Constraint : cIterativeRelationalConstraint#3_cIterativeRelationalConstraint
    # For each country, total allocation of investments (such that investments country is country) is less than or equal to 500
    # Label: CT_10_For_each_country__total_allocation_of_investments__such_that_investments_country_is_country__is_less_than_or_equal_to_500
    join_Country = list_of_Country[[]].reset_index().merge(list_of_Investment.reset_index(), left_on=['id_of_Country'], right_on=['country']).set_index(['id_of_Country', 'id_of_Investment'])
    groupbyLevels = ['id_of_Country']
    groupby_Country = join_Country.allocationVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_Country.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar <= 500, u'For each country, total allocation of investments (such that investments country is country) is less than or equal to 500', row)
    
    # [ST_11] Constraint : cIterativeRelationalConstraint#4_cIterativeRelationalConstraint
    # For each investment, allocation is less than or equal to 300
    # Label: CT_11_For_each_investment__allocation_is_less_than_or_equal_to_300
    for row in list_of_Investment.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar <= 300, u'For each investment, allocation is less than or equal to 300', row)


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    if mdl.get_solve_status() == JobSolveStatus.UNKNOWN:
        print('UNKNOWN cause: %s' % mdl.get_solve_details().status)
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('Internal constraint', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = list_of_conflicts.append({'constraint': label, 'context': str(context), 'detail': ct},
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_Investment_solution = pd.DataFrame(index=list_of_Investment.index)
    list_of_Investment_solution['allocationVar'] = msol.get_values(list_of_Investment.allocationVar.values)
    list_of_Investment_solution['selectionVar'] = msol.get_values(list_of_Investment.selectionVar.values)
    list_of_Investment_solution['integerSubAllocationVar'] = msol.get_values(list_of_Investment.integerSubAllocationVar.values)
    investmentAllocation = pd.DataFrame(index=list_of_Investment.index)
    
    # Adding extra columns based on Solution Schema
    investmentAllocation['investment allocation decision'] = list_of_Investment_solution['allocationVar']
    investmentAllocation['selected investments decision'] = list_of_Investment_solution['selectionVar']
    investmentAllocation['investment pieces decision'] = list_of_Investment_solution['integerSubAllocationVar']
    investmentAllocation['investment stock price'] = list_of_Investment['stock_price']
    investmentAllocation['investment recommendation'] = list_of_Investment['recommendation']
    investmentAllocation['investment industry'] = list_of_Investment['industry']
    investmentAllocation['investment index'] = list_of_Investment['index_']
    investmentAllocation['investment expected return amount'] = list_of_Investment['expected_return_amount']
    investmentAllocation['investment expected return'] = list_of_Investment['expected_return']
    investmentAllocation['investment country'] = list_of_Investment['country']
    list_of_Investment_maxValueAllocation = pd.Series([1000] * len(list_of_Investment)).to_frame('maxValueAllocation').set_index(list_of_Investment.index)
    join_Investment = list_of_Investment.join(list_of_Investment_maxValueAllocation.maxValueAllocation, how='inner')
    investmentAllocation['investment maxValueAllocation'] = join_Investment['maxValueAllocation']
    list_of_Investment_minValueAllocationForAssignment = pd.Series([10] * len(list_of_Investment)).to_frame('minValueAllocationForAssignment').set_index(list_of_Investment.index)
    join_Investment = list_of_Investment.join(list_of_Investment_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    investmentAllocation['investment minValueAllocationForAssignment'] = join_Investment['minValueAllocationForAssignment']
    investmentAllocation = investmentAllocation.round({'investment allocation decision': 2, 'investment pieces decision': 2})
    

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['investmentAllocation'] = investmentAllocation[['investment allocation decision', 'selected investments decision', 'investment pieces decision', 'investment stock price', 'investment recommendation', 'investment industry', 'investment index', 'investment expected return amount', 'investment expected return', 'investment country', 'investment maxValueAllocation', 'investment minValueAllocationForAssignment']].reset_index().rename(columns= {'id_of_Investment': 'investment'})
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Instantiate CustomCode class if definition exists
try:
    custom_code = CustomCode(globals())
except NameError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()


from docplex.mp.progress import ProgressListener
from docplex.util.environment import add_abort_callback, remove_abort_callback
from functools import partial


class SolutionListener(ProgressListener):
    def __init__(self):
        super(SolutionListener, self).__init__()
        self._cpx_incumbent_sol = None

    def requires_solution(self):
        return True

    def notify_solution(self, cpx_incumbent_sol):
        self._cpx_incumbent_sol = cpx_incumbent_sol


def save_and_write_last_solution_callback(sol_listener, outputs):
    if sol_listener._cpx_incumbent_sol:
        export_solution(sol_listener._cpx_incumbent_sol)
    write_all_outputs(outputs)


solution_listener = SolutionListener()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

#
model.add_progress_listener(solution_listener)
env = get_environment()
# Remove default abort callbacks
for cb in env.abort_callbacks:
    remove_abort_callback(cb)
# Add new abort callback to store latest found solution, if any
add_abort_callback(partial(save_and_write_last_solution_callback, solution_listener, outputs))

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
