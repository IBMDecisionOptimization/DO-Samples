from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys

# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


from pandas.api.types import is_string_dtype


def helper_check_data_type(df, column, df_label, check_type):
    if not column in df.columns:
        print('Column "%s" does not exist in table "%s"' % (column, df_label))
        return False
    non_nan_values = df[column][~df[column].isnull()]
    if check_type == 'INTEGER':
        k = non_nan_values.dtype.kind
        if k != 'i':
            if k == 'f':
                non_integer_values = non_nan_values.values[np.where([not x.is_integer() for x in non_nan_values])]
                if len(non_integer_values) > 0:
                    print('Column "%s" of table "%s" contains non-integer value(s) which violates expected type: %s' % (column, df_label, non_integer_values))
                    return False
            else:
                print('Column "%s" of table "%s" is non-numeric which violates expected type: %s' % (column, df_label, non_nan_values.values))
                return False
    elif check_type == 'FLOAT' or check_type == 'NUMBER':
        non_float_values = non_nan_values.values[np.where([not isinstance(x, (int, float)) for x in non_nan_values])]
        k = non_nan_values.dtype.kind
        if not k in ['i', 'f']:
            print('Column "%s" of table "%s" contains non-float value(s) which violates expected type: %s' % (column, df_label, non_float_values))
            return False
    elif check_type == 'BOOLEAN':
        non_bool_values = non_nan_values.values[np.where([not isinstance(x, bool) for x in non_nan_values])]
        if len(non_bool_values) > 0:
            print('Column "%s" of table "%s" contains non-boolean value(s) which violates expected type: %s' % (column, df_label, non_bool_values))
            return False
    elif check_type == 'Date' or check_type == 'DateTime':
        try:
            pd.to_datetime(non_nan_values)
        except ValueError as e:
            print('Column "%s" of table "%s" cannot be converted to a DateTime : %s' % (column, df_label, str(e)))
            return False
    elif check_type == 'Time':
        try:
            pd.to_timedelta(non_nan_values)
        except ValueError as e:
            try:
                # Try appending ':00' in case seconds are not represented in time
                pd.to_timedelta(non_nan_values + ':00')
            except ValueError as e:
                print('Column "%s" of table "%s" cannot be converted to a Time : %s' % (column, df_label, str(e)))
                return False
    elif check_type == 'STRING':
        if not is_string_dtype(non_nan_values):
            print('Column "%s" of table "%s" is not of type "String"' % (column, df_label))
            return False
    else:
        raise Exception('Invalid check_type: %s' % check_type)
    return True


def helper_check_foreignKey_values(source_df, source_column, source_df_label, target_df, target_column, target_df_label):
    non_nan_values = source_df[source_column][~source_df[source_column].isnull()]
    invalid_FK_values = non_nan_values[~non_nan_values.isin(target_df[target_column])].values
    if len(invalid_FK_values) > 0:
        print('FK Column "%s" of table "%s" contains values that do not exist in PK column "%s" of target table "%s": %s' % (source_column, source_df_label, target_column, target_df_label, invalid_FK_values))
        return False
    return True


def helper_check_unique_primaryKey_values(df, key_cols, df_label):
    df_grp = df.groupby(key_cols).size()
    invalid_pk_values = df_grp[df_grp > 1].reset_index()[key_cols].values
    if len(invalid_pk_values) > 0:
        print('Non-unique values for PK of table "%s": %s' % (df_label, invalid_pk_values))
        return False
    return True


# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'Candidates': ['id_of_Candidates'],
    'Campaign': ['id_of_Campaign'],
    'Customer': ['id_of_Customer'],
    'cAssignmentValueConcept': ['id_of_Candidates'],
    'cResource': ['id_of_Customer'],
    'cActivity': ['id_of_Campaign']}
helper_property_id_to_column_names_map = {
    'Candidates.Customer': 'Customer',
    'cAssignmentValueConcept.value': 'expected_value',
    'Customer.id': 'id',
    'Campaign.id': 'id',
    'Candidates.expected value': 'expected_value',
    'cAssignmentValueConcept.resource': 'Customer',
    'cAssignmentValueConcept.activity': 'Campaign',
    'Customer.age': 'age',
    'Campaign.max customers': 'max_customers',
    'Candidates.Campaign': 'Campaign'}


# Data model definition for each table
# Data collection: list_of_Campaign ['id', 'max_customers']
# Data collection: list_of_Candidates ['Campaign', 'Customer', 'expected_value', '__line']
# Data collection: list_of_Customer ['age', 'id']

# Create a pandas Dataframe for each data table
list_of_Campaign = inputs[u'Campaign']
list_of_Campaign = list_of_Campaign[[u'id', u'max customers']].copy()
list_of_Campaign.rename(columns={u'id': 'id', u'max customers': 'max_customers'}, inplace=True)
list_of_Candidates = inputs[u'Candidates']
list_of_Candidates = list_of_Candidates[[u'Campaign', u'Customer', u'expected value']].copy()
list_of_Candidates.rename(columns={u'Campaign': 'Campaign', u'Customer': 'Customer', u'expected value': 'expected_value'}, inplace=True)
list_of_Customer = inputs[u'Customer']
list_of_Customer = list_of_Customer[[u'age', u'id']].copy()
list_of_Customer.rename(columns={u'age': 'age', u'id': 'id'}, inplace=True)

# Perform input data checking against schema configured in Modelling Assistant along with unicity of PK values
data_check_result = True
# --- Handling data checking for table: Campaign
data_check_result &= helper_check_data_type(list_of_Campaign, 'max_customers', 'Campaign', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Campaign, ['id'], 'Campaign')
# --- Handling data checking for table: Candidates
data_check_result &= helper_check_foreignKey_values(list_of_Candidates, 'Campaign', 'Candidates', list_of_Campaign, 'id', 'Campaign')
data_check_result &= helper_check_foreignKey_values(list_of_Candidates, 'Customer', 'Candidates', list_of_Customer, 'id', 'Customer')
data_check_result &= helper_check_data_type(list_of_Candidates, 'expected_value', 'Candidates', 'NUMBER')
# --- Handling data checking for table: Customer
data_check_result &= helper_check_data_type(list_of_Customer, 'age', 'Customer', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Customer, ['id'], 'Customer')
if not data_check_result:
    # Stop execution here
    raise Exception('Data checking detected errors')

# Set index when a primary key is defined
list_of_Campaign.set_index('id', inplace=True)
list_of_Campaign.sort_index(inplace=True)
list_of_Campaign.index.name = 'id_of_Campaign'
list_of_Candidates.index.name = 'id_of_Candidates'
list_of_Customer.set_index('id', inplace=True)
list_of_Customer.sort_index(inplace=True)
list_of_Customer.index.name = 'id_of_Customer'


# Create data frame as cartesian product of: Customer x Campaign
list_of_ResourceAssignment = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Customer.index, list_of_Campaign.index), names=['id_of_Customer', 'id_of_Campaign']))




def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_ResourceAssignment['resourceAssignmentVar'] = mdl.binary_var_list(len(list_of_ResourceAssignment))


    # Definition of model
    # Objective cMaximizeAssignmentsAutoSelected-
    # Combine weighted criteria: 
    # 	cMaximizeAssignmentsAutoSelected cMaximizeAssignmentsAutoSelected 1.2{
    # 	assignment = cResourceAssignment[Customer, Campaign],
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = decisionPath(cResourceAssignment[Customer, Campaign])} with weight 5.0
    # 	cMaximizeAssignmentValue cMaximizeAssignmentValue 1.2{
    # 	assignment = cResourceAssignment[Customer, Campaign],
    # 	assignmentValue = Candidates,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = total Candidates [join dimensions(cResourceAssignment[Customer, Campaign] / Customer, cResourceAssignment[Customer, Campaign] / Campaign) with dimensions(Candidates / Customer, Candidates / Campaign)] / expected value over cResourceAssignment[Customer, Campaign]} with weight 5.0
    agg_ResourceAssignment_resourceAssignmentVar_SG1 = mdl.sum(list_of_ResourceAssignment.resourceAssignmentVar)
    join_ResourceAssignment_SG2 = list_of_ResourceAssignment.reset_index().merge(list_of_Candidates.reset_index(), left_on=['id_of_Customer', 'id_of_Campaign'], right_on=['Customer', 'Campaign']).set_index(['id_of_Customer', 'id_of_Campaign', 'id_of_Candidates'])
    join_Candidates_SG2 = list_of_Candidates.join(join_ResourceAssignment_SG2, rsuffix='_right', how='inner')
    groupby_Candidates_SG2 = join_Candidates_SG2.expected_value.groupby(level=['id_of_Customer', 'id_of_Campaign']).sum().to_frame()
    join_ResourceAssignment_SG2_2 = list_of_ResourceAssignment.reset_index().merge(groupby_Candidates_SG2.reset_index(), left_on=['id_of_Customer', 'id_of_Campaign'], right_on=['id_of_Customer', 'id_of_Campaign']).set_index(['id_of_Customer', 'id_of_Campaign'])
    join_ResourceAssignment_SG2_2['conditioned_expected_value'] = join_ResourceAssignment_SG2_2.resourceAssignmentVar * join_ResourceAssignment_SG2_2.expected_value
    agg_ResourceAssignment_conditioned_expected_value_SG2 = mdl.sum(join_ResourceAssignment_SG2_2.conditioned_expected_value)
    
    kpis_expression_list = [
        (1, 16.0, agg_ResourceAssignment_resourceAssignmentVar_SG1, 1, 0, u'the number of Customer to Campaign assignments'),
        (1, 16.0, agg_ResourceAssignment_conditioned_expected_value_SG2, 1, 0, u'overall quality or value of Customer to Campaign assignments according to Candidates')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset), publish_name=kpi_name)
    
    mdl.maximize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cLimitNumberOfResourcesAssignedToEachActivity_cIterativeRelationalConstraint
    # The number of Customers assigned to each Campaign is less than or equal to max customers
    # Label: CT_1_The_number_of_Customers_assigned_to_each_Campaign_is_less_than_or_equal_to_max_customers
    groupbyLevels = ['id_of_Campaign']
    groupby_ResourceAssignment = list_of_ResourceAssignment.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    join_ResourceAssignment = groupby_ResourceAssignment.join(list_of_Campaign.max_customers, how='inner')
    for row in join_ResourceAssignment[join_ResourceAssignment.max_customers.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAssignmentVar <= row.max_customers, u'The number of Customers assigned to each Campaign is less than or equal to max customers', row)
    
    # [ST_2] Constraint : cBasicLimitNumberOfActivitiesAssignedToEachResource_cIterativeRelationalConstraint
    # The number of Campaigns assigned to each Customer is less than or equal to 1
    # Label: CT_2_The_number_of_Campaigns_assigned_to_each_Customer_is_less_than_or_equal_to_1
    groupbyLevels = ['id_of_Customer']
    groupby_ResourceAssignment = list_of_ResourceAssignment.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_ResourceAssignment.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAssignmentVar <= 1, u'The number of Campaigns assigned to each Customer is less than or equal to 1', row)


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    if mdl.get_solve_status() == JobSolveStatus.UNKNOWN:
        print('UNKNOWN cause: %s' % mdl.get_solve_details().status)
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('N/A', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = list_of_conflicts.append({'constraint': label, 'context': str(context), 'detail': ct},
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_ResourceAssignment_solution = pd.DataFrame(index=list_of_ResourceAssignment.index)
    list_of_ResourceAssignment_solution['resourceAssignmentVar'] = msol.get_values(list_of_ResourceAssignment.resourceAssignmentVar.values)
    NotAssignedCampaigns = pd.DataFrame(index=list_of_ResourceAssignment.index)
    
    # Adding extra columns based on Solution Schema
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Customer.age, how='inner')
    NotAssignedCampaigns['Customer age'] = join_ResourceAssignment['age']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Campaign.max_customers, how='inner')
    NotAssignedCampaigns['Campaign max customers'] = join_ResourceAssignment['max_customers']
    
    NotAssignedCampaigns['_INTERNAL_resourceAssignmentVar'] = list_of_ResourceAssignment_solution.resourceAssignmentVar
    NotAssignedCampaigns = NotAssignedCampaigns[NotAssignedCampaigns._INTERNAL_resourceAssignmentVar <= 0.5]
    NotAssignedCampaigns = NotAssignedCampaigns.drop('_INTERNAL_resourceAssignmentVar', axis='columns')

    AssignedCampaigns = pd.DataFrame(index=list_of_ResourceAssignment.index)
    groupbyLevels = ['id_of_Customer', 'id_of_Campaign']
    groupby_ResourceAssignment = list_of_ResourceAssignment_solution.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    AssignedCampaigns['Campaign assignments'] = groupby_ResourceAssignment['resourceAssignmentVar']
    groupbyLevels = ['id_of_Customer', 'id_of_Campaign']
    groupby_ResourceAssignment = list_of_ResourceAssignment_solution.resourceAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    AssignedCampaigns['Customer assignments'] = groupby_ResourceAssignment['resourceAssignmentVar']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Customer.age, how='inner')
    AssignedCampaigns['Customer age'] = join_ResourceAssignment['age']
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Campaign.max_customers, how='inner')
    AssignedCampaigns['Campaign max customers'] = join_ResourceAssignment['max_customers']
    
    AssignedCampaigns['_INTERNAL_resourceAssignmentVar'] = list_of_ResourceAssignment_solution.resourceAssignmentVar
    AssignedCampaigns = AssignedCampaigns[AssignedCampaigns._INTERNAL_resourceAssignmentVar > 0.5]
    AssignedCampaigns = AssignedCampaigns.drop('_INTERNAL_resourceAssignmentVar', axis='columns')


    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['AssignedCampaigns'] = AssignedCampaigns[['Campaign assignments', 'Customer assignments', 'Customer age', 'Campaign max customers']].reset_index().rename(columns= {'id_of_Campaign': 'Campaign', 'id_of_Customer': 'Customer'})
        outputs['NotAssignedCampaigns'] = NotAssignedCampaigns[['Customer age', 'Campaign max customers']].reset_index().rename(columns= {'id_of_Campaign': 'Campaign', 'id_of_Customer': 'Customer'})
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Import custom code definition if module exists
try:
    from custom_code import CustomCode
    custom_code = CustomCode(globals())
except ImportError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
