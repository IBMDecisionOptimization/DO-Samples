from docplex.mp.utils import *
from docplex.cp.model import *
from docplex.cp.expression import _FLOATING_POINT_PRECISION
from docplex.util.environment import get_environment
import time
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys

# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


# Convert type to 'int64'
def helper_int64_convert(arg):
    if pd.__version__ < '0.20.0':
        return arg.astype('int64', raise_on_error=False)
    else:
        return arg.astype('int64', errors='ignore')

from pandas.api.types import is_string_dtype


def helper_check_data_type(df, column, df_label, check_type):
    if not column in df.columns:
        print('Column "%s" does not exist in table "%s"' % (column, df_label))
        return False
    non_nan_values = df[column][~df[column].isnull()]
    if check_type == 'INTEGER':
        k = non_nan_values.dtype.kind
        if k != 'i':
            if k == 'f':
                non_integer_values = non_nan_values.values[np.where([not x.is_integer() for x in non_nan_values])]
                if len(non_integer_values) > 0:
                    print('Column "%s" of table "%s" contains non-integer value(s) which violates expected type: %s' % (column, df_label, non_integer_values))
                    return False
            else:
                print('Column "%s" of table "%s" is non-numeric which violates expected type: %s' % (column, df_label, non_nan_values.values))
                return False
    elif check_type == 'FLOAT' or check_type == 'NUMBER':
        non_float_values = non_nan_values.values[np.where([not isinstance(x, (int, float)) for x in non_nan_values])]
        k = non_nan_values.dtype.kind
        if not k in ['i', 'f']:
            print('Column "%s" of table "%s" contains non-float value(s) which violates expected type: %s' % (column, df_label, non_float_values))
            return False
    elif check_type == 'BOOLEAN':
        non_bool_values = non_nan_values.values[np.where([not isinstance(x, bool) for x in non_nan_values])]
        if len(non_bool_values) > 0:
            print('Column "%s" of table "%s" contains non-boolean value(s) which violates expected type: %s' % (column, df_label, non_bool_values))
            return False
    elif check_type == 'Date' or check_type == 'DateTime':
        try:
            pd.to_datetime(non_nan_values)
        except ValueError as e:
            print('Column "%s" of table "%s" cannot be converted to a DateTime : %s' % (column, df_label, str(e)))
            return False
    elif check_type == 'Time':
        try:
            pd.to_timedelta(non_nan_values)
        except ValueError as e:
            try:
                # Try appending ':00' in case seconds are not represented in time
                pd.to_timedelta(non_nan_values + ':00')
            except ValueError as e:
                print('Column "%s" of table "%s" cannot be converted to a Time : %s' % (column, df_label, str(e)))
                return False
    elif check_type == 'STRING':
        if not is_string_dtype(non_nan_values):
            print('Column "%s" of table "%s" is not of type "String"' % (column, df_label))
            return False
    else:
        raise Exception('Invalid check_type: %s' % check_type)
    return True


def helper_check_foreignKey_values(source_df, source_column, source_df_label, target_df, target_column, target_df_label):
    non_nan_values = source_df[source_column][~source_df[source_column].isnull()]
    invalid_FK_values = non_nan_values[~non_nan_values.isin(target_df[target_column])].values
    if len(invalid_FK_values) > 0:
        print('FK Column "%s" of table "%s" contains values that do not exist in PK column "%s" of target table "%s": %s' % (source_column, source_df_label, target_column, target_df_label, invalid_FK_values))
        return False
    return True


def helper_check_unique_primaryKey_values(df, key_cols, df_label):
    df_grp = df.groupby(key_cols).size()
    invalid_pk_values = df_grp[df_grp > 1].reset_index()[key_cols].values
    if len(invalid_pk_values) > 0:
        print('Non-unique values for PK of table "%s": %s' % (df_label, invalid_pk_values))
        return False
    return True


# Parse and convert an integer Series to a date Series
# Integer value represents the number of schedule units (time granularity for engine) since horizon start
def helper_convert_int_series_to_date(sched_int_series):
    return pd.to_datetime(sched_int_series * secs_per_day / duration_units_per_day / schedUnitPerDurationUnit * nanosecs_per_sec + horizon_start_date.value, errors='coerce')

# Return index values of a multi-index from index name
def helper_get_level_values(df, column_name):
    return df.index.get_level_values(df.index.names.index(column_name))

# Convert a duration Series to a Series representing the number of scheduling units
def helper_convert_duration_series_to_scheduling_unit(duration_series, nb_input_data_units_per_day):
    return helper_int64_convert(duration_series * duration_units_per_day * schedUnitPerDurationUnit / nb_input_data_units_per_day)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


# Parse and convert a date to an integer
# Integer value represents the number of schedule units (time granularity for engine) since horizon start
def helper_convert_date_to_int(date):
    return int((date - horizon_start_date).value / nanosecs_per_sec * duration_units_per_day * schedUnitPerDurationUnit / secs_per_day)


def helper_parse_and_convert_date_to_int(date_as_str):
    return helper_convert_date_to_int(pd.to_datetime(date_as_str))

# Label constraint
expr_counter = 1
def helper_add_labeled_cpo_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(expr_counter)
        expr_counter += 1
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'cTask': ['id_of_Activity'],
    'Subcontractor': ['id_of_Subcontractor'],
    'Activity': ['id_of_Activity'],
    'cUnaryResource': ['id_of_Subcontractor']}
helper_property_id_to_column_names_map = {
    'Activity.Duration in days': 'Duration_in_days',
    'Activity.Activity': 'Activity',
    'cTask.fixedDuration': 'Duration_in_days',
    'Subcontractor.Name': 'Name'}


# Data model definition for each table
# Data collection: list_of_Activity ['Duration_in_days', 'Activity']
# Data collection: list_of_Activity_Preceding_activities ['Activity', 'Preceding_activities']
# Data collection: list_of_Activity_Possible_Subcontractors ['Activity', 'Possible_Subcontractors']
# Data collection: list_of_Subcontractor ['Name']

# Create a pandas Dataframe for each data table
list_of_Activity = inputs[u'Activity']
list_of_Activity = list_of_Activity[[u'Duration in days', u'Activity']].copy()
list_of_Activity.rename(columns={u'Duration in days': 'Duration_in_days', u'Activity': 'Activity'}, inplace=True)
# --- Handling implicit table for multi-valued property
list_of_Activity_Preceding_activities = inputs[u'Activity'][[u'Activity', u'Preceding activities']].copy()
list_of_Activity_Preceding_activities.rename(columns={u'Activity': 'Activity', u'Preceding activities': 'Preceding_activities'}, inplace=True)
list_of_Activity_Preceding_activities.set_index('Activity', inplace=True)
list_of_Activity_Preceding_activities_split = list_of_Activity_Preceding_activities['Preceding_activities'].str.split(',').apply(pd.Series).stack().str.strip()
list_of_Activity_Preceding_activities_split.index = list_of_Activity_Preceding_activities_split.index.droplevel(-1)
list_of_Activity_Preceding_activities = pd.DataFrame(list_of_Activity_Preceding_activities_split, columns=['Preceding_activities']).reset_index()
# --- Handling implicit table for multi-valued property
list_of_Activity_Possible_Subcontractors = inputs[u'Activity'][[u'Activity', u'Possible Subcontractors']].copy()
list_of_Activity_Possible_Subcontractors.rename(columns={u'Activity': 'Activity', u'Possible Subcontractors': 'Possible_Subcontractors'}, inplace=True)
list_of_Activity_Possible_Subcontractors.set_index('Activity', inplace=True)
list_of_Activity_Possible_Subcontractors_split = list_of_Activity_Possible_Subcontractors['Possible_Subcontractors'].str.split(',').apply(pd.Series).stack().str.strip()
list_of_Activity_Possible_Subcontractors_split.index = list_of_Activity_Possible_Subcontractors_split.index.droplevel(-1)
list_of_Activity_Possible_Subcontractors = pd.DataFrame(list_of_Activity_Possible_Subcontractors_split, columns=['Possible_Subcontractors']).reset_index()
list_of_Subcontractor = inputs[u'Subcontractor']
list_of_Subcontractor = list_of_Subcontractor[[u'Name']].copy()
list_of_Subcontractor.rename(columns={u'Name': 'Name'}, inplace=True)

# Perform input data checking against schema configured in Modelling Assistant along with unicity of PK values
data_check_result = True
# --- Handling data checking for table: Activity
data_check_result &= helper_check_data_type(list_of_Activity, 'Duration_in_days', 'Activity', 'NUMBER')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Activity, ['Activity'], 'Activity')
# --- Handling data checking for implicit table: Activity_Preceding activities
data_check_result &= helper_check_foreignKey_values(list_of_Activity_Preceding_activities, 'Activity', 'Activity_Preceding activities', list_of_Activity, 'Activity', 'Activity')
data_check_result &= helper_check_foreignKey_values(list_of_Activity_Preceding_activities, 'Preceding_activities', 'Activity_Preceding activities', list_of_Activity, 'Activity', 'Activity')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Activity_Preceding_activities, ['Activity', 'Preceding_activities'], 'Activity_Preceding activities')
# --- Handling data checking for implicit table: Activity_Possible Subcontractors
data_check_result &= helper_check_foreignKey_values(list_of_Activity_Possible_Subcontractors, 'Activity', 'Activity_Possible Subcontractors', list_of_Activity, 'Activity', 'Activity')
data_check_result &= helper_check_foreignKey_values(list_of_Activity_Possible_Subcontractors, 'Possible_Subcontractors', 'Activity_Possible Subcontractors', list_of_Subcontractor, 'Name', 'Subcontractor')
data_check_result &= helper_check_unique_primaryKey_values(list_of_Activity_Possible_Subcontractors, ['Activity', 'Possible_Subcontractors'], 'Activity_Possible Subcontractors')
# --- Handling data checking for table: Subcontractor
data_check_result &= helper_check_unique_primaryKey_values(list_of_Subcontractor, ['Name'], 'Subcontractor')
if not data_check_result:
    # Stop execution here
    raise Exception('Data checking detected errors')

# Set index when a primary key is defined
list_of_Activity.set_index('Activity', inplace=True)
list_of_Activity.sort_index(inplace=True)
list_of_Activity.index.name = 'id_of_Activity'
list_of_Activity_Preceding_activities.set_index('Activity', inplace=True)
list_of_Activity_Preceding_activities.sort_index(inplace=True)
list_of_Activity_Preceding_activities.index.name = 'id_of_Activity'
list_of_Activity_Possible_Subcontractors.set_index('Activity', inplace=True)
list_of_Activity_Possible_Subcontractors.sort_index(inplace=True)
list_of_Activity_Possible_Subcontractors.index.name = 'id_of_Activity'
list_of_Subcontractor.set_index('Name', inplace=True)
list_of_Subcontractor.sort_index(inplace=True)
list_of_Subcontractor.index.name = 'id_of_Subcontractor'
# Define time granularity for scheduling
schedUnitPerDurationUnit = 1440  # DurationUnit is days
duration_units_per_day = 1.0


# Define global constants for date to integer conversions
horizon_start_date = pd.to_datetime('Mon Sep 14 00:00:00 UTC 2020')
horizon_end_date = horizon_start_date + pd.Timedelta(days=3650)
nanosecs_per_sec = 1000.0 * 1000 * 1000
secs_per_day = 3600.0 * 24

# Convert all input durations to internal time unit
list_of_Activity['INTERNAL_RAW_Duration_in_days'] = list_of_Activity['Duration_in_days']
list_of_Activity['Duration_in_days'] = helper_convert_duration_series_to_scheduling_unit(list_of_Activity.Duration_in_days, 1.0)


# Create data frame as cartesian product of: Activity x Subcontractor
list_of_SchedulingAssignment = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Activity.index, list_of_Subcontractor.index), names=['id_of_Activity', 'id_of_Subcontractor']))




def build_model():
    mdl = CpoModel()

    # Definition of model variables
    list_of_SchedulingAssignment['interval'] = interval_var_list(len(list_of_SchedulingAssignment), end=(INTERVAL_MIN, helper_convert_date_to_int(horizon_end_date)), optional=True)
    list_of_SchedulingAssignment['schedulingAssignmentVar'] = list_of_SchedulingAssignment.interval.apply(mdl.presence_of)
    list_of_Activity['interval'] = interval_var_list(len(list_of_Activity), end=(INTERVAL_MIN, helper_convert_date_to_int(horizon_end_date)), optional=True)
    list_of_Activity['taskStartVar'] = list_of_Activity.interval.apply(mdl.start_of)
    list_of_Activity['taskEndVar'] = list_of_Activity.interval.apply(mdl.end_of)
    list_of_Activity['taskDurationVar'] = list_of_Activity.interval.apply(mdl.size_of)
    list_of_Activity['taskAbsenceVar'] = 1 - list_of_Activity.interval.apply(mdl.presence_of)
    list_of_Activity['taskPresenceVar'] = list_of_Activity.interval.apply(mdl.presence_of)


    # Definition of model
    # Objective cMinimizeMakespan-
    # Combine weighted criteria: 
    # 	cMinimizeMakespan cMinimizeMakespan 1.2{
    # 	task = Activity,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) taskEnd = decisionPath(cTaskEnd[Activity]),
    # 	(static) numericExpr = max of decisionPath(cTaskEnd[Activity]) over cTaskEnd[Activity]} with weight 5.0
    agg_Activity_taskEndVar_SG1 = mdl.max(list_of_Activity.taskEndVar)
    
    kpis_expression_list = [
        (1, 1.0, agg_Activity_taskEndVar_SG1 / schedUnitPerDurationUnit, 1, 0, u'time to complete all Activities')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for i, (_, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name) in enumerate(kpis_expression_list):
        kpi_var = integer_var(name='kpi_' + repr(i + 1))
        mdl.add(kpi_var >= kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) - 1 + _FLOATING_POINT_PRECISION)
        mdl.add(kpi_var <= kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset))
        mdl.add_kpi(kpi_var, name=kpi_name)
    
    mdl.add(minimize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list])))
    
    # [ST_1] Constraint : cLimitNumberOfResourcesAssignedToEachActivitySched_cIterativeRelationalConstraint
    # The number of Subcontractor assignments for each Activity is equal to 1
    # Label: CT_1_The_number_of_Subcontractor_assignments_for_each_Activity_is_equal_to_1
    groupbyLevels = ['id_of_Activity']
    groupby_SchedulingAssignment = list_of_SchedulingAssignment.schedulingAssignmentVar.groupby(level=groupbyLevels).sum().to_frame()
    for row in groupby_SchedulingAssignment.itertuples(index=True):
        helper_add_labeled_cpo_constraint(mdl, row.schedulingAssignmentVar == 1, u'The number of Subcontractor assignments for each Activity is equal to 1', row)
    
    # [ST_2] Constraint : cForceTaskPresence_cIterativeRelationalConstraint
    # All Activities are scheduled
    # Label: CT_2_All_Activities_are_scheduled
    for row in list_of_Activity.itertuples(index=True):
        helper_add_labeled_cpo_constraint(mdl, row.taskAbsenceVar != 1, u'All Activities are scheduled', row)
    
    # [ST_3] Constraint : cSetFixedDurationSpezProp_cSetFixedDurationPath
    # The schedule must respect the duration specified for each Activity
    # Label: CT_3_The_schedule_must_respect_the_duration_specified_for_each_Activity
    for row in list_of_Activity[list_of_Activity.Duration_in_days.notnull()].itertuples(index=True):
        helper_add_labeled_cpo_constraint(mdl, size_of(row.interval, int(row.Duration_in_days)) == int(row.Duration_in_days), u'The schedule must respect the duration specified for each Activity', row)
    
    # [ST_4] Constraint : cTaskPredecessorsNoDelayConstraintDirect_cTaskPredecessorsConstraint
    # Each Activity starts after the end of Preceding activities
    # Label: CT_4_Each_Activity_starts_after_the_end_of_Preceding_activities
    join_Activity = list_of_Activity.join(list_of_Activity_Preceding_activities.Preceding_activities, how='inner')
    join_Activity_2 = join_Activity.reset_index().join(list_of_Activity.interval, on=['Preceding_activities'], rsuffix='_right', how='inner').set_index(['id_of_Activity'])
    for row in join_Activity_2.itertuples(index=True):
        helper_add_labeled_cpo_constraint(mdl, end_before_start(row.interval_right, row.interval), u'Each Activity starts after the end of Preceding activities', row)
    
    # [ST_5] Constraint : cDefineCompatibleResources_cCategoryCompatibilityConstraintOnPair
    # For each Subcontractor to Activity assignment, assigned Subcontractor must be one of Possible Subcontractors of Activity
    # Label: CT_5_For_each_Subcontractor_to_Activity_assignment__assigned_Subcontractor_must_be_one_of_Possible_Subcontractors_of_Activity
    join_Activity = list_of_Activity.join(list_of_Activity_Possible_Subcontractors.Possible_Subcontractors, how='inner')
    join_SchedulingAssignment = list_of_SchedulingAssignment.reset_index().set_index(['id_of_Activity']).join(join_Activity.Possible_Subcontractors, how='inner').reset_index().set_index(['id_of_Activity', 'id_of_Subcontractor'])
    filtered_SchedulingAssignment = join_SchedulingAssignment.loc[join_SchedulingAssignment.Possible_Subcontractors == helper_get_level_values(join_SchedulingAssignment, 'id_of_Subcontractor')].copy()
    drop_list_of_SchedulingAssignment = list_of_SchedulingAssignment.drop(labels=[-1], level='id_of_Subcontractor')
    helper_add_labeled_cpo_constraint(mdl, mdl.sum(drop_list_of_SchedulingAssignment.schedulingAssignmentVar[~drop_list_of_SchedulingAssignment.index.isin(filtered_SchedulingAssignment.index.values)]) == 0, u'For each Subcontractor to Activity assignment, assigned Subcontractor must be one of Possible Subcontractors of Activity')
    
    # Scheduling internal structure
    groupby_SchedulingAssignment = list_of_SchedulingAssignment.reset_index()[['id_of_Activity', 'interval']].groupby(['id_of_Activity'])['interval'].apply(list).to_frame()
    join_SchedulingAssignment = groupby_SchedulingAssignment.join(list_of_Activity.interval, rsuffix='_right', how='inner')
    for row in join_SchedulingAssignment.itertuples(index=False):
        mdl.add(synchronize(row.interval_right, row.interval))
    
    # link presence if not alternative
    groupby_SchedulingAssignment = list_of_SchedulingAssignment.schedulingAssignmentVar.groupby(level=['id_of_Activity']).agg(lambda l: mdl.max(l.tolist())).to_frame()
    join_SchedulingAssignment = groupby_SchedulingAssignment.join(list_of_Activity.taskPresenceVar, how='inner')
    for row in join_SchedulingAssignment.itertuples(index=False):
        mdl.add(row.schedulingAssignmentVar <= row.taskPresenceVar)
    
    # no overlap
    groupby_SchedulingAssignment = list_of_SchedulingAssignment.reset_index()[['id_of_Subcontractor', 'interval']].groupby(['id_of_Subcontractor'])['interval'].apply(list).to_frame()
    for row in groupby_SchedulingAssignment.reset_index().itertuples(index=False):
        mdl.add(no_overlap(row.interval))


    return mdl


def solve_model(mdl):
    params = CpoParameters()
    params.TimeLimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(params)
    # Update parameters value according to environment variables definition
    cpo_param_env_prefix = 'ma.cpo.'
    cpo_params = [name[4:] for name in dir(CpoParameters) if name.startswith('set_')]
    for param in cpo_params:
        env_param = cpo_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            params[param] = param_value

    solver = CpoSolver(mdl, params=params, trace_log=True)
    try:
        for i, msol in enumerate(solver):
            ovals = msol.get_objective_values()
            print("Objective values: {}".format(ovals))
            # Initialize dict iterator that works in Py2.7 and Py3
            kpis_dict = msol.get_kpis()
            kpis_iterator = getattr(kpis_dict, "viewitems", None)
            if not kpis_iterator:
                kpis_iterator = kpis_dict.items
            for k, v in kpis_iterator():
                print('%s --> %s' % (k, v))
            export_solution(msol)
            if ovals is None:
                break  # No objective: stop after first solution
        # If model is infeasible, invoke conflict refiner to return
        if solver.get_last_solution().get_solve_status() == SOLVE_STATUS_INFEASIBLE:
            conflicts = solver.refine_conflict()
            export_conflicts(conflicts)
    except CpoException as e:
        # Solve has been aborted from an external action
        print('An exception has been raised: %s' % str(e))
        raise e


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for item, index in zip(conflicts.member_constraints, range(len(conflicts.member_constraints))):
        label, context = expr_to_info.get(item.name, ('N/A', item.name))
        constraint_detail = expression._to_string(item)
        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, constraint_detail))
        list_of_conflicts = list_of_conflicts.append(pd.DataFrame({'constraint': label, 'context': str(context), 'detail': constraint_detail},
                                                                  index=[index], columns=['constraint', 'context', 'detail']))

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_SchedulingAssignment_solution = pd.DataFrame(index=list_of_SchedulingAssignment.index)
    list_of_SchedulingAssignment_solution['schedulingAssignmentVar'] = list_of_SchedulingAssignment.interval.apply(lambda r: (1 if msol.solution.get_var_solution(r).is_present() else 0) if msol.solution.get_var_solution(r) else np.NaN)
    list_of_Activity_solution = pd.DataFrame(index=list_of_Activity.index)
    list_of_Activity_solution = list_of_Activity_solution.join(pd.DataFrame([msol.solution[interval] if msol.solution[interval] else (None, None, None) for interval in list_of_Activity.interval], index=list_of_Activity.index, columns=['taskStartVar', 'taskEndVar', 'taskDurationVar']))
    list_of_Activity_solution['taskStartVarDate'] = helper_convert_int_series_to_date(list_of_Activity_solution.taskStartVar).dt.strftime('%Y-%m-%d %H:%M:%S')
    list_of_Activity_solution['taskEndVarDate'] = helper_convert_int_series_to_date(list_of_Activity_solution.taskEndVar).dt.strftime('%Y-%m-%d %H:%M:%S')
    list_of_Activity_solution.taskStartVar /= schedUnitPerDurationUnit
    list_of_Activity_solution.taskEndVar /= schedUnitPerDurationUnit
    list_of_Activity_solution.taskDurationVar /= schedUnitPerDurationUnit
    list_of_Activity_solution['taskAbsenceVar'] = list_of_Activity.interval.apply(lambda r: (1 if msol.solution.get_var_solution(r).is_absent() else 0) if msol.solution.get_var_solution(r) else np.NaN)
    list_of_Activity_solution['taskPresenceVar'] = list_of_Activity.interval.apply(lambda r: (1 if msol.solution.get_var_solution(r).is_present() else 0) if msol.solution.get_var_solution(r) else np.NaN)
    
    # Add 'Next' task and 'Sequence index' information when assignments are associated with unary resources
    list_of_SchedulingAssignment_solution_filtered = list_of_SchedulingAssignment_solution[list_of_SchedulingAssignment_solution.schedulingAssignmentVar > 0.5]
    if list_of_SchedulingAssignment_solution_filtered.shape[0] > 0:
        df = list_of_SchedulingAssignment_solution_filtered.join(list_of_Activity_solution, rsuffix='_right')
        df_grp = df.reset_index().sort_values(by=['id_of_Subcontractor', 'taskStartVar', 'taskEndVar']).set_index(list_of_SchedulingAssignment_solution_filtered.index.names).groupby(level='id_of_Subcontractor')
        df2 = df_grp['taskStartVar'].rank(ascending=True, method='first').to_frame(name='Sequence index')
        df2['Next'] = df2.index.get_level_values(df2.index.names.index('id_of_Activity'))
        df2['Next'] = df2.groupby(level='id_of_Subcontractor')['Next'].shift(-1)
        list_of_SchedulingAssignment_solution['Sequence index'] = df2['Sequence index'].astype(np.int32)
        list_of_SchedulingAssignment_solution['Next'] = df2['Next']
    else:
        list_of_SchedulingAssignment_solution['Sequence index'] = None
        list_of_SchedulingAssignment_solution['Next'] = None
    NotScheduledActivities = pd.DataFrame(index=list_of_Activity.index)
    
    # Adding extra columns based on Solution Schema
    NotScheduledActivities['Activity Duration in days'] = list_of_Activity['Duration_in_days'] / schedUnitPerDurationUnit
    
    NotScheduledActivities['_INTERNAL_taskStartVar'] = list_of_Activity_solution.taskStartVar
    NotScheduledActivities = NotScheduledActivities[NotScheduledActivities._INTERNAL_taskStartVar.isnull()]
    NotScheduledActivities = NotScheduledActivities.drop('_INTERNAL_taskStartVar', axis='columns')

    ScheduledActivities = pd.DataFrame(index=list_of_SchedulingAssignment.index)
    ScheduledActivities['Subcontractor to Activity assignment'] = list_of_SchedulingAssignment_solution['schedulingAssignmentVar']
    join_SchedulingAssignment = list_of_SchedulingAssignment.join(list_of_Activity_solution.taskStartVar, how='inner')
    ScheduledActivities['Activity start'] = join_SchedulingAssignment['taskStartVar']
    join_SchedulingAssignment = list_of_SchedulingAssignment.join(list_of_Activity_solution.taskStartVarDate, how='inner')
    ScheduledActivities['Activity start Date'] = join_SchedulingAssignment['taskStartVarDate']
    join_SchedulingAssignment = list_of_SchedulingAssignment.join(list_of_Activity_solution.taskDurationVar, how='inner')
    ScheduledActivities['Activity duration'] = join_SchedulingAssignment['taskDurationVar']
    join_SchedulingAssignment = list_of_SchedulingAssignment.join(list_of_Activity_solution.taskEndVar, how='inner')
    ScheduledActivities['Activity end'] = join_SchedulingAssignment['taskEndVar']
    join_SchedulingAssignment = list_of_SchedulingAssignment.join(list_of_Activity_solution.taskEndVarDate, how='inner')
    ScheduledActivities['Activity end Date'] = join_SchedulingAssignment['taskEndVarDate']
    ScheduledActivities['Next'] = list_of_SchedulingAssignment_solution['Next']
    ScheduledActivities['Sequence index'] = list_of_SchedulingAssignment_solution['Sequence index']
    join_SchedulingAssignment = list_of_SchedulingAssignment.join(list_of_Activity.Duration_in_days, how='inner')
    ScheduledActivities['Activity Duration in days'] = join_SchedulingAssignment['Duration_in_days'] / schedUnitPerDurationUnit
    
    ScheduledActivities['_INTERNAL_schedulingAssignmentVar'] = list_of_SchedulingAssignment_solution.schedulingAssignmentVar
    ScheduledActivities = ScheduledActivities[ScheduledActivities._INTERNAL_schedulingAssignmentVar > 0.5]
    ScheduledActivities = ScheduledActivities.drop('_INTERNAL_schedulingAssignmentVar', axis='columns')


    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['ScheduledActivities'] = ScheduledActivities[['Subcontractor to Activity assignment', 'Activity start', 'Activity start Date', 'Activity duration', 'Activity end', 'Activity end Date', 'Next', 'Sequence index', 'Activity Duration in days']].reset_index().rename(columns= {'id_of_Subcontractor': 'Subcontractor', 'id_of_Activity': 'Activity'})
        outputs['NotScheduledActivities'] = NotScheduledActivities[['Activity Duration in days']].reset_index().rename(columns= {'id_of_Activity': 'Activity'})
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Import custom code definition if module exists
try:
    from custom_code import CustomCode
    custom_code = CustomCode(globals())
except ImportError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
solve_model(model)
elapsed_time = time.time() - start_time
print('solve + export of all intermediate solutions done in ' + str(elapsed_time) + ' secs')
